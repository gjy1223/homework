"""

"""
import random


def result(num):
    for i in range(0, num):
        count = random.randint(2,3)
        result = build_timu(count)
        print(result)


# 生成表达式和结果
def build_timu(x):
    list = []
    if (x == 2):
        list.append(str(random.randint(0, 100)))
        list.append(str(buildFuhao(random.randint(0, 3))))
        list.append(str(random.randint(0, 100)))
        list.append(str(buildFuhao(random.randint(0, 3))))
        list.append(str(random.randint(0, 100)))

#  将除法结果都变成整数
        c = random.randint(1, 10)
        z = 0
        while z < 3:
            z += 1
            if list[z] == '/' :
                list[z-1] = int(list[z+1])*c

        num = jisuan(list)
        if (num == None):
            build_timu(2)
        else:
            list.append("=")
            list.append(num)
    elif (x == 3):
        list.append(str(random.randint(0, 100)))
        list.append(str(buildFuhao(random.randint(0, 3))))
        list.append(str(random.randint(0, 100)))
        list.append(str(buildFuhao(random.randint(0, 3))))
        list.append(str(random.randint(0, 100)))
        list.append(str(buildFuhao(random.randint(0, 3))))
        list.append(str(random.randint(0, 100)))

 #  将除法结果都变成整数    
        c = random.randint(1, 10)
        j = 0
        while j < 5 :
            j += 1
            if list[j] == '/' :
                list[j-1] = int(list[j+1])*c


        num = jisuan(list)
        if (num == None):
            build_timu(3)
        else:
            list.append("=")
            list.append(num)

    list2=[str(i) for i in list]
    list3 = ''.join(list2)
    return list3


# 随机产生运算符号
def buildFuhao(b):
    if (b == 0):
        return "+"
    if (b == 1):
        return "-"
    if (b == 2):
        return "*"
    if (b == 3):
        return "/"


# 计算公式的结果
def jisuan(list):

    n = len(list)
    num = 0
    if (n == 5):
        try:
            num = eval(str(list[0]) + str(list[1]) + str(list[2]) + str(list[3]) + str(list[4]))
        except ZeroDivisionError:
            return None
    elif (n == 7):
        try:
            num = eval(
                str(list[0]) + str(list[1]) + str(list[2]) + str(list[3]) + str(list[4]) + str(list[5]) + str(list[6]))
        except ZeroDivisionError:
            print(None)

    if (num != int(num)):
        return None
    else:
        return num


num = input("请输入生成的题目数量：")
result(int(num))
