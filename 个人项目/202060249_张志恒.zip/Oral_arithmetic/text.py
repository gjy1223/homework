import random

input1 = 3
input2 = 0
a = 101
if input2 == 0:
    b_max = 100 - a
    b = random.randint(1, b_max +1)  # 加1，防止b_max = 0,
    num2 = b

c = a + b