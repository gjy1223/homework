'''
1.接收题目数量
2.生成随机数和运算符
3.不出现非整数
4.输出文本文件
'''

import random
i=0
list1=[]
n= int(input('请输入题目数量：'))
def computor(x,y,k):  #定义计算函数
    if  k==0:
        return x+y
    elif k==1:
        return x-y
    elif k==2:
        return x*y
    else:
        return x/y
#输出到文本文件
f = open('./subject.txt', 'w')     # w 在当前目录下创建文本文件文件，若存在，则覆盖原文件内容
while i<=n:
        num_1 = random.randint(1, 100)  #生成3个[0-100]随机整数
        num_2 = random.randint(1, 100)
        num_3 = random.randint(1, 100)
        a = random.randint(0, 3)      #生成2个[0-3]随机整数，代表运算符
        b = random.randint(0, 3)

        if a==0:             #生成两个运算符
            way1="+"
        elif a==1:
            way1="-"
        elif a==2:
             way1="×"
        elif a==3:
             way1="÷"

        if b==0:
            way2="+"
        elif b==1:
            way2="-"
        elif b==2:
            way2="×"
        else :
            way2="÷"
        if  b>1:
            result=computor(num_2,num_3,b)    #第二个运算符是乘除
            result=computor(num_1,result,a)
        else :
            result=computor(num_1,num_2,a)
            result = computor(result, num_3, a)

        if (result < 0) | (result > 100) :
            continue

        if type(result)==int:                 #结果必须整数
            word="{0}{1}{2}{3}{4}={5}".format(num_1,way1,num_2,way2,num_3,result)
            list1.append([num_1,a,num_2,b,num_3,result])
            print(word, file=f)
            i=i+1
        else:
            continue

f.close()  #关闭文件
