import random
import os


#判断是否可以用于整除
def Judge(num,len1):
    for i in range(len1 - 1):
        if num[i + 1] != 0 and num[i] % num[i + 1] != 0 :
            return False
    return True
    
#判断数组当中是否有/
def JudgeFu(choose,len1) :
    for i in range(len1) :
        if(choose[i] == '/'):
            return True
    return False

#建立字符串
def build(choose,num,countNum,countFu):
    s1 = ''
    i = 0
    j = 0
    while(i < countNum) :
        s1+=str(num[i])
        i+=1
        if j < countFu :
            s1+=str(choose[j])
            j+=1
    return s1

#基本运算
#def calculate(s):
#        list=[]
#        pivot='+'
#        num=0
#        sum=0
#        n=len(s)
#        for i in range (n):
#            if(s[i]!='+' and s[i]!='-' and s[i]!='/' and s[i]!='*'):
#                num=num*10+int(s[i]-'0')
#            if(not is_number(s[i])):
#               if(s[i]=='+'):
#                   list.append[num]
#               elif(s[i]=='-'):
#                   list.append[-num]
#               elif(s[i]=='*'):
#                   list[-1]=list[-1]*num
#               else:
#                   list[-1]=list[-1]/num
#               pivot=s[i]
#               num=0
#        for j in list:
#            sum+=j
#        return sum
           
 

ch = ['+','-','*','/']
print('请输入需要生成的算式的个数')
n = eval(input('No1:'))
print('The Question:')
count=0
file_handle=open('subject.txt',mode='w')
while True:
        
        countNum = random.randint(2,4)   #数字个数
        countFu = countNum - 1             #符号个数
        num=random.sample(range(0,1000),countNum)  #数组式随机生成数字
        choose=random.sample(ch,countFu)        #随机去符号
        if(JudgeFu(choose,countFu)):
            if(not Judge(num,countNum)):
                continue
        str1 = build(choose,num,countNum,countFu)
        flag = str1.find('/')
        if(flag != -1):
            if(str1[flag + 1] == '0'):
                continue
        print(str1 + '=')
        num2 = eval(str1)
        count+=1
        str1=str1+'='+str(num2)
        file_handle.write(str1+'\n')
        if count==n :
            break
        #print(str1)
print('---------END-----------')
file_handle.close()      
os.system("pause")
    
 

    