package tools;

import java.util.regex.Pattern;

public class CalculateTool {
	
	/**
	 * 该方法判断输入字符串是否为整数
	 * @param str
	 * @return
	 */
	public static boolean isInteger(String str) {  
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");  
        return pattern.matcher(str).matches();  
  }
	
	/**
	 * 该方法返回中缀表达式的值
	 * @param expression
	 * @return
	 */
	public static double expressionValue(String expression) {
		//创建两个栈
    	ArrayStack2 numStack = new ArrayStack2(10);
    	ArrayStack2 operStack = new ArrayStack2(10);
    	
    	//定义相关变量
	    int index = 0;
	    double num1 = 0;
	    double num2 =0;
	    double oper = 0;
	    double res = 0;
	    char ch = ' ';//保存扫描的char
	    String keepNum = "";//用于拼接多位数
	    
	    //使用循环来扫描字符串
		while (true) {
			// 获取字符
			ch = expression.substring(index, index + 1).charAt(0);
			// 判断ch是什么
			if (operStack.isOper(ch)) {
				// 判断当前符号栈是否为空
				if (!operStack.isEmpty()) {
					// 不为空
					while (!operStack.isEmpty() && operStack.priority(ch) <= operStack.priority(operStack.peek())) {
						if (numStack.Length() >= 1)
							num1 = numStack.pop();
						num2 = numStack.pop();
						oper = operStack.pop();
						res = numStack.cal(num1, num2, oper);
						// 把运算结果入数栈
						numStack.push(res);
					}
					// 当前操作符优先级大于栈内操作符优先级
					operStack.push(ch);
				} else {
					// 为空
					operStack.push(ch);
				}
			} else {
				// 1.数字是多位数的情况
				keepNum += ch;
 
				// 判断ch是否为字符串最后一个元素
				if (index == expression.length() - 1) {
					numStack.push(Integer.parseInt(keepNum));
				} else {
					// 判断下一个字符是不是符号
					if (operStack.isOper(expression.substring(index + 1, index + 2).charAt(0))) {
						numStack.push(Integer.parseInt(keepNum));
						// 重要的地方,清空keepNum
						keepNum = "";
					}
				}
			}
	    	index++;
	    	if(index >= expression.length()) {
	    		break;
	    	}
	    }
	    //表达式扫描完毕后,进行运算
	    while(true) {
	    	//如果符号栈为空,则计算结束,数栈中只有1个值
	    	if(operStack.isEmpty()) {
	    		break;
	    	}
	    	num1 = numStack.pop();
			num2 = numStack.pop();
			oper = operStack.pop();
			res = numStack.cal(num1, num2, oper);
			numStack.push(res);
	    }
	    return numStack.pop();
	}
}
 
//先创建一个栈,需要扩展功能
class ArrayStack2 {
	// 列写栈的成员变量
	private int top = -1;
	private double[] array;
	private int maxSize;
 
	ArrayStack2(int MaxSize) {
		this.maxSize = MaxSize;
		//初始化数组
		array = new double[this.maxSize];
	}
	//返回栈中有效元素的个数
	public int Length() {
		return top+1;
	}
	//返回当前栈顶的元素,不是出栈
	public double peek() {
		return array[top];
	}
	
	//判断栈满方法
	public boolean isFull() {
		return top == maxSize - 1;
	}
	
	//判断栈空方法
	public boolean isEmpty() {
		return top == -1;
	}
 
	// 定义入栈方法
	public void push(double value) {
		// 判断是否栈满
		if (isFull()) {
			System.out.println("栈满");
			return;
		} else {
			array[++top] = value;
		}
	}
 
	// 定义出栈方法
	public double pop() {
		// 判断是否栈空
		double value = 0;
		if (isEmpty()) {
			//抛出异常
			throw new RuntimeException("栈空");
		} else {
		    value = array[top--];
		}
		return value;
	}
	
	//栈的遍历
	public void list() {
		//判断栈是否为空
		if (isEmpty()) {
			System.out.println("栈空");
			return;
		} else {
		    for(int i=top;i>=0;i--) {
		    	System.out.print(array[i]+" ");
		    }
		}
	}
	
	//返回运算符的优先级，优先级是程序员来确定的,优先级使用数字
	//表示,数字越大,则优先级越高
	public int priority(double oper) {
		if(oper == '*'|| oper == '/') {
			return 1;
		} else if(oper == '+'|| oper == '-') {
			return 0;
		} else {
			return -1;
		}
	}
	
	//判断是不是一个运算符
	public boolean isOper(char val) {
		return val == '+'|| val == '-' || 
				val == '*' || val == '/';				
	}
	
	//运算方法
	public double cal(double num1,double num2,double oper) {
		double res = 0;
		switch((int)oper) {
		case '+':
			res = num1+num2;
			break;
		case '-':
			res = num2-num1;//注意顺序
			break;
		case '*':
			res = num1*num2;
			break;
		case '/':
			res = num2/num1;
			break;
		default:break;
		
		}
		return res;
	}
}