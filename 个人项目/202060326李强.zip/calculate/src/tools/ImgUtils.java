package tools;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

//���ǻ�ȡͼƬ�Ĺ�����
public class ImgUtils {
	public static BufferedImage getImage(String path) {
		try {
			BufferedImage img = ImageIO.read(new File(path));
			return img;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
