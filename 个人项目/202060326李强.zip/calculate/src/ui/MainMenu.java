package ui;

import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;

import panel.CalculatePanel;
import tools.ImgUtils;

public class MainMenu {
	
	
	public static void main(String[] args) {
		Font f = new Font("����",Font.PLAIN,18);
		JFrame frame = new JFrame();
		frame.setSize(960, 720);
		frame.setLocationRelativeTo(null);
		frame.setTitle("����������");
		frame.setIconImage(ImgUtils.getImage("img/icon.png"));
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		CalculatePanel panel = new CalculatePanel();
		panel.setLayout(null);
		frame.add(panel);
		frame.setVisible(true);
	}
}
