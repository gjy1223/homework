package panel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import tools.CalculateTool;
import tools.ImgUtils;

//�������������������
public class CalculatePanel extends JPanel{
	
	private BufferedImage bgImg;
	private BufferedImage titleImg;
	private BufferedImage numImg;
	private BufferedImage runBgImg;
	private BufferedImage startBgImg;
	private BufferedImage endBgImg;
	private BufferedImage submitImg;
	private BufferedImage returnImg;
	private JTextField questionCount;
	private boolean clickText;
	private boolean addJText;
	private boolean mousePressStart;
	private boolean mousePressEnd;
	private boolean mousePressSubmit;
	private boolean mousePressReturn;
	private boolean flag;
	
	private boolean startInterface = true;
	private boolean runInterface;
	
	
	private int operatorCount;//���������
	private int numberCount;//��������
	private int n;//��Ŀ����
	private int index = 0;//��������ʼ����
	
	private char[] operators;//������ɵ������ 
	private int[] numbers;//������ɵ�����
	private JTextField[] inputAnswer;//���ÿ����Ŀ����Ĵ������
	
	private List<String> expressions;//��ſ�����
	private List<Integer> answers;//��Ŵ�
	private List<String> expressionAndAnswers;//��Ŵ��д𰸵ı���ʽ
	private List<Integer> textAnswers;//����ı���������Ĵ�
	private String expression = "";//������
	
	//���췽��
	public CalculatePanel() {
		//��ʼ������
		bgImg = ImgUtils.getImage("img/bgImg.jpg");
		titleImg = ImgUtils.getImage("img/titleImg.png");
		numImg = ImgUtils.getImage("img/numImg.png");
		runBgImg = ImgUtils.getImage("img/runBg.jpg");
		startBgImg = ImgUtils.getImage("img/startBg.jpg");
		endBgImg = ImgUtils.getImage("img/endBg.jpg");
		submitImg = ImgUtils.getImage("img/submitImg.jpg");
		returnImg = ImgUtils.getImage("img/returnBg.jpg");
		
		//����2��3�������
		operatorCount = Math.random() > 0.5 ? 2 : 3;
		numberCount = operatorCount + 1;
		operators = new char[operatorCount];
		numbers = new int[numberCount];
		expressions = new ArrayList<>();
		answers = new ArrayList<>();
		expressionAndAnswers = new ArrayList<>();
		textAnswers = new ArrayList<>();
		
		//��ʼ���ı���
		questionCount = new JTextField("1~12");
		questionCount.setFont(new Font(null,Font.BOLD,30));
		questionCount.setForeground(Color.LIGHT_GRAY);
		questionCount.setHorizontalAlignment(JTextField.CENTER);
		questionCount.setEditable(clickText);
		questionCount.setBounds(500, 390, 300, 60);
		questionCount.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				if(!clickText) {
					clickText = true;
					questionCount.setEditable(clickText);
					questionCount.setText("");
					questionCount.getCaret().setVisible(true);
					questionCount.setForeground(Color.BLACK);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
			
		});
		this.add(questionCount);
		
		//������굥���¼�
		MouseAdapter adapter = new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
				if(startInterface && e.getX() > 330 && e.getX() < 550 && e.getY() > 480 && e.getY() < 550) {
					mousePressStart = true;
					repaint();
				} else if(startInterface && e.getX() > 330 && e.getX() < 550 && e.getY() > 580 && e.getY() < 660) {
					mousePressEnd = true;
					repaint();
				} else if(runInterface && e.getX() > 100 && e.getX() < 320 && e.getY() > 540 && e.getY() < 617) {
					mousePressSubmit = true;
					repaint();
				} else if(runInterface && e.getX() > 600 && e.getX() < 820 && e.getY() > 540 && e.getY() < 617) {
					mousePressReturn = true;
					repaint();
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if(startInterface && e.getX() > 330 && e.getX() < 550 && e.getY() > 480 && e.getY() < 550) {
					mousePressStart = false;
					repaint();
					String input = questionCount.getText();
					if(CalculateTool.isInteger(input) && !input.equals("")) {
						int tmp = Integer.parseInt(input);
						if(tmp >= 1 && tmp <= 12) {
							startInterface = false;
							runInterface = true;
							n = Integer.parseInt(input);
							generateMultExpression(n);//��n���Ϸ��ı���ʽ�洢������
							expressionAndAnswer();
							try {
								addToFile();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							inputAnswer = new JTextField[n];
							addJText = true;
							repaint();
						} else if(tmp <= 0 || tmp > 12) {
							JOptionPane.showMessageDialog(new JPanel(), "����1~12֮����������", "ע��",JOptionPane.WARNING_MESSAGE);
						} else {
							JOptionPane.showMessageDialog(new JPanel(), "��������Ŀ����", "ע��",JOptionPane.WARNING_MESSAGE);
						}
					} else {
						JOptionPane.showMessageDialog(new JPanel(), "����1~12֮����������", "ע��",JOptionPane.WARNING_MESSAGE);
					}
				} else if(startInterface && e.getX() > 330 && e.getX() < 550 && e.getY() > 580 && e.getY() < 660) {
					mousePressEnd = false;
					repaint();
					int r=JOptionPane.showConfirmDialog(null, "ȷ���˳���", "����",JOptionPane.YES_NO_OPTION);
	                if(r==JOptionPane.YES_OPTION){
	                    System.exit(0);
	                }
				} else if(runInterface && e.getX() > 100 && e.getX() < 320 && e.getY() > 540 && e.getY() < 617) {
					mousePressSubmit = false;
					flag = true;//��־�������ύ�ͷ��¼�
					//�������ȡ�ı���������Ĵ𰸣������Ǵ浵������
					textAnswers.clear();
					getTextVal();
					if(textAnswers.size() != n) {
						flag = false;
						JOptionPane.showMessageDialog(new JPanel(), "�������������ύ", "ע��",JOptionPane.WARNING_MESSAGE);
					}
					repaint();
				} else if(runInterface && e.getX() > 600 && e.getX() < 820 && e.getY() > 540 && e.getY() < 617) {
					mousePressReturn = false;
					repaint();
					int r=JOptionPane.showConfirmDialog(null, "ȷ��������������", "����",JOptionPane.YES_NO_OPTION);
					if(r==JOptionPane.YES_OPTION){
	                    startInterface = true;
	                    runInterface = false;
	                    flag = false;
	                    deleteAnswerFields();
	                    addInputText();
	                    expressions.clear();
	                    answers.clear();
	                    expressionAndAnswers.clear();
	                    textAnswers.clear();
	                    repaint();
	                }
				}
			}
		};
		addMouseListener(adapter);
		addMouseMotionListener(adapter);
	}
	/**
	 * �÷����Ƴ�����е��ı���
	 */
	public void deleteAnswerFields() {
		for(int i = 0; i < inputAnswer.length; i++) {
			this.remove(inputAnswer[i]);
		}
	}
	/**
	 * �÷���������������ı���
	 */
	public void addInputText() {
		this.add(questionCount);
	}
	/**
	 * �÷���������ȡ��������еĴ�
	 */
	public void getTextVal() {
		for(int i = 0; i < inputAnswer.length; i++) {
			String tmp = inputAnswer[i].getText();
			if(!tmp.equals("")) {
				textAnswers.add(Integer.parseInt(tmp));
			}
		}
	}
	/**
	 * �÷��������д𰸵ı���ʽ������ļ�
	 * @throws IOException 
	 */
	public void addToFile() throws IOException {
		BufferedWriter bwrite = new BufferedWriter(new FileWriter("output.txt"));
		for(int i = 0; i < expressionAndAnswers.size(); i++) {
			String tmp = expressionAndAnswers.get(i);
			bwrite.write(tmp);
			bwrite.newLine();
			bwrite.flush();
		}
		bwrite.close();
	}
	/**
	 * �÷���������ʽ���ƴ������
	 */
	public void expressionAndAnswer() {
		for(int i = 0; i < expressions.size(); i++) {
			String tmp = expressions.get(i) + answers.get(i);
			expressionAndAnswers.add(tmp);
		}
	}
	/**
	 * �÷�������n���Ϸ��ı���ʽ
	 * @param n
	 */
	public void generateMultExpression(int n) {
		for(int i = 0; i < n; i++) {
			String tmp = generateOneExpression();
			expressions.add(tmp+"=");
		}
	}
	/**
	 * �÷�������һ���Ϸ��ı���ʽ
	 */
	public String generateOneExpression() {
		double res = expressionValue();
		while(Math.round(res) != res) {
			res = expressionValue();
		}
		answers.add((int) res);
		return expression;
	}
	/**
	 * �÷�����������ʽ��ֵ
	 * @return
	 */
	public double expressionValue() {
		operatorCount = Math.random() > 0.5 ? 2 : 3;
		numberCount = operatorCount + 1;
		operators = new char[operatorCount];
		numbers = new int[numberCount];
		//���������������
		generateOperators();
		generateNumbers();
		//ƴ����׺����ʽ
		expression = "";
		for(int i = 0, j = 0; i < numbers.length && j < operators.length; i++, j++) {
			expression += numbers[i];
			expression += operators[j];
		}
		expression += numbers[numbers.length-1];//ƴ�����һ������
		
		return CalculateTool.expressionValue(expression);
	}
	/**
	 * �÷�������������������
	 */
	public void generateOperators() {
		//����2~3�������
		for(int i = 0; i < operatorCount; i++) {
			int num = new Random().nextInt(4);
			if(num == 0) {
				operators[i] = '+';
			} else if(num == 1) {
				operators[i] = '-';
			} else if(num == 2) {
				operators[i] = '*';
			} else if(num == 3) {
				operators[i] = '/';
			}
		}		
	}
	/**
	 * �÷������������������
	 */
	public void generateNumbers() {
		//��������
		for(int i = 0; i < numberCount; i++) {
			int num = new Random().nextInt(101);
			numbers[i] = num;
		}
	}
	
	/**
	 * ���ǻ�ͼ����
	 */
	public void paint(Graphics g) {
		super.paint(g);
		if(startInterface) {
			this.setBackground(Color.GRAY);
			g.drawImage(titleImg, 200, 20, null);
			g.drawImage(numImg, 300, 400, null);
			if(mousePressStart) {
				g.drawImage(startBgImg, 335, 485, null);
			} else{
				g.drawImage(startBgImg, 330, 480, null);
			}
			if(mousePressEnd) {
				g.drawImage(endBgImg, 335, 585, null);
			} else {
				g.drawImage(endBgImg, 330, 580, null);
			}
		} else if(runInterface) {
			this.remove(questionCount);
			this.setBackground(Color.LIGHT_GRAY);
			if(mousePressSubmit) {
				g.drawImage(submitImg, 105, 545, null);
			} else {
				g.drawImage(submitImg, 100, 540, null);
			}
			if(mousePressReturn) {
				g.drawImage(returnImg, 605, 545, null);
			} else {
				g.drawImage(returnImg, 600, 540, null);
			}
			//�����ｫ������Ŀ����ⶼ������
			int lenx = 50, leny = 80;
			boolean allRight = true;
			for(int i = 0; i < expressions.size(); i++) {
				String tmp = expressions.get(i);
				if(flag) {
					if(!textAnswers.get(i).equals(answers.get(i))) {
						g.setColor(Color.RED);
						allRight = false;
					} else {
						g.setColor(Color.BLACK);
					}
				}
				g.setFont(new Font("arial", Font.BOLD, 45));
				if(i != 0 && i % 2 == 0 ) {
					lenx = 50;
					leny += 80;
					g.drawString(tmp, lenx, leny);
				} else {
					g.drawString(tmp, lenx, leny);
				}
				lenx += 450;
			}
			if(flag && allRight) {
				g.setFont(new Font("arial", Font.BOLD, 80));
				g.setColor(Color.BLUE);
				g.drawString("You are the best!", 160, 300);
			}
			//������ֻ����һ�α�ǩ
			if(addJText) {
				int lenx2 = 360, leny2 = 30;
				for(int i = 0; i < inputAnswer.length; i++) {
					inputAnswer[i] = new JTextField();
					inputAnswer[i].setFont(new Font(null,Font.BOLD,30));
					inputAnswer[i].setHorizontalAlignment(JTextField.CENTER);
					if(i != 0 && i % 2 == 0 ) {
						lenx2 = 360;
						leny2 += 80;
						inputAnswer[i].setBounds(lenx2, leny2, 100, 60);
					} else {
						inputAnswer[i].setBounds(lenx2, leny2, 100, 60);
					}
					lenx2 += 450;
				}
				for(int i = 0; i < inputAnswer.length; i++) {
					this.add(inputAnswer[i]);
				}
				addJText = false;
			}
		}
		
	}
}
