import random
import operator

symbol = '+-*/' #四种运算符号

def compute_three_int(a,b,c):#计算三个随机数
    s1 = random.choice(symbol)#随机出一种运算符号
    s2 = random.choice(symbol)
    if s1 == '/' and s2 != '/':#处理除号，如果检测到除号，把除数和被除数变成倍数关系
        a = b * random.randint(1,3)
    if s1 == '/' and s2 == '/':
        a = b * random.randint(1,3)
        c = (a / b) // c
        if c == 0:
            c = 1

    if s2 == '/' and s1 != '/':
        b = c * random.randint(1,3)
    
    shizi = str(a) + s1 + str(b) + s2 + str(c) #组合三个随机数和两个随机符号成为一个式子
    print(shizi + "=")
    result = eval(shizi)
    #print(result)
    #path = 'C:/Users/Administrator/Desktop/123.txt'
    f = open('../正确答案.txt',"a")
    f.write(shizi+"="+str(result))#将答案写入TXT文件
    f.write("\n")

def compute_four_int(a,b,c,d):#计算四个随机数
    s1 = random.choice(symbol)
    s2 = random.choice(symbol)
    s3 = random.choice(symbol)
    
    if s1 == '/' and s2 != '/' and s3 != '/':
        a = b * random.randint(1,3)
    if s2 == '/' and s1 != '/' and s3 != '/':
        b = c * random.randint(1,3)
    if s3 == '/' and s1 != '/' and s2 != '/':
        c = d * random.randint(1,3)
    if s1 == '/' and s2 == '/' and s3 != '/':
        a = b * random.randint(1,3)
        c = (a / b) // c
        if c == 0:
            c = 1
    if s2 == '/' and s3 == '/' and s1 != '/':
        b = c * random.randint(1,3)
        d = (b / c) // d
        if d == 0:
            d = 1
    if s1 == '/' and s3 == '/' and s2 != '/':
        a = b * random.randint(1,3)
        c = d * random.randint(1,3)
    if s1 == '/' and s2 == '/' and s3 == '/':
        a = b * random.randint(1,3)
        c = (a / b) // c
        if c == 0:
            c = 1
        d = (a / b / c) // c
        if d == 0:
            d = 1
                
   
    shizi = str(a) + s1 + str(b) + s2 + str(c) + s3 + str(d)
    print(shizi + "=")
    result = eval(shizi)
    #print(result)
    #path = 'C:Users/Administrator/Desktop/123.txt'
    f = open('../正确答案.txt',"a")
    f.write(shizi+"="+str(result))
    f.write("\n")




def create_dengshi(n):#按输入的个数n创建计算题
   
    for i in range(0,n):
        s = random.randint(0,1) #随机创三个数的计算题或四个数的计算题
        if s == 0: 
            a = random.randint(1,30)#随机数的随机范围
            b = random.randint(1,30)
            c = random.randint(1,30)
            print(i+1,end = '、') #每个式子前打印序号
            compute_three_int(a,b,c)  #调用计算三个随机数的函数
        else:
            a = random.randint(1,30)
            b = random.randint(1,30)
            c = random.randint(1,30)
            d = random.randint(1,30)
            print(i+1,end = '、')
            compute_four_int(a,b,c,d)
    


def main():
    
    while True:
        n = int(input('请输入等式个数：'))
        f = open('../正确答案.txt',"a")
        f.write('######################################')
        f.write('\n')
        f.write('输入个数为%d的答案：' % n)
        f.write("\n")
        f.close()
        create_dengshi(n)
        f = open('../正确答案.txt',"a")
        f.write('######################################')

    

if __name__ == '__main__':
    main()