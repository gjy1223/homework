"""要求
•	程序接收一个命令行参数 n，然后随机产生 n 道加减乘除（分别使用符号+-*/来表示）练习题，每个数字在 0 和 100 之间，运算符在2个 到 3 个 之间。
•	由于阿超的孩子才上一年级，并不知道分数所以软件所出的练习题在运算过程中不得出现非整数，比如不能出现 3÷5+2=2.6 这样的算式。
•	练习题生成好后，将生成的n道练习题及其对应的正确答案输出到一个文件 subject.txt 中。
•	当程序接收的参数为4时，以下为一个输出文件示例。
13+17-1=29
11*15-5=160
3+10+4-16=1
15÷5+3-2=4
"""
import random

# 运算符
OPERATOR = ['+', '-', '*', '/']
# 得到的全部等式
EQUATION = ['姓名:刘崧\n', '学号:202060203\n']
# 接收输入的数字
n = input("小朋友，需要几道算术题呢？需要输入一个数字哦！输入的数字为:")
# 规范用户输入
while True:
    try:
        n = int(n)
        break
    except:
        n = input("小朋友，不输入数字是要挨打的哦！输入的数字为:")

# 产生n个计算题
for i in range(n):
    # 计算题
    equation = ""
    while True:
        # zero的作用为让式子在算除法的时候除数不为0
        zero = 0
        for j in range(4):
            if zero == 1:
                s = str(random.randint(1, 101))
            else:
                s = str(random.randint(0, 101))
            equation += s
            if j != 3:
                operator = random.choice(OPERATOR)
                if operator == '/':
                    zero = 1
                else:
                    zero = 0
                equation += operator
        # 得到的答案是整数时输出
        if isinstance(eval(equation), int):
            EQUATION.append(equation + '=' + str(eval(equation)) + '\n')
            break
        else:
            equation = ""
# 将算术题写入文件
with open(r'subject.txt', mode='wt', encoding='utf-8') as f:
    for i in EQUATION:
        f.write(i)
