import random
import math


# 生成2-3个运算符的四则运算函数

def make_question():

    sym = ['＋', '－', '×', '÷']

    f = random.randint(2, 3)  # 符号个数

    result = 0  # 结果值

    n1 = random.randint(1, 100)  # 整数1

    n2 = random.randint(1, 100)  # 整数2

    n3 = random.randint(1, 100)  # 整数3

    n4 = random.randint(1, 100)  # 整数4

    f1 = random.randint(0, 3)  # 符号1

    f2 = random.randint(0, 3)  # 符号2

    f3 = random.randint(0, 3)  # 符号3

    if f == 2:  # 三个数运算

        if f1 == 0:

            if f2 == 0:  # n1+n2+n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 1:  # n1+n2-n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 2:  # n1+n2*n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 3:  # n1+n2/n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

        elif f1 == 1:

            if f2 == 0:  # n1-n2+n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 1:  # n1-n2-n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 2:  # n1-n2*n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 3:  # n1-n2/n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

        elif f1 == 2:

            if f2 == 0:  # n1*n2+n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 1:  # n1*n2-n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 2:  # n1*n2*n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 3:  # n1*n2/n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

        elif f1 == 3:

            if f2 == 0:  # n1/n2+n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 1:  # n1/n2-n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 2:  # n1/n2*n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

            elif f2 == 3:  # n1/n2/n3

                result, n1, n2, n3 = three_arithmetic(n1, n2, n3, f1, f2)

    elif f == 3:  # 四个数运算

        if f1 == 0:

            if f2 == 0:

                if f3 == 0:  # n1+n2+n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1+n2+n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1+n2+n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1+n2+n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 1:

                if f3 == 0:  # n1+n2-n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1+n2-n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1+n2-n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1+n2-n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 2:

                if f3 == 0:  # n1+n2*n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1+n2*n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1+n2*n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1+n2*n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 3:

                if f3 == 0:  # n1+n2/n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1+n2/n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1+n2/n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1+n2/n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

        if f1 == 1:

            if f2 == 0:

                if f3 == 0:  # n1-n2+n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1-n2+n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1-n2+n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1-n2+n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 1:

                if f3 == 0:  # n1-n2-n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1-n2-n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1-n2-n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1-n2-n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 2:

                if f3 == 0:  # n1-n2*n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1-n2*n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1-n2*n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1-n2*n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 3:

                if f3 == 0:  # n1-n2/n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1-n2/n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1-n2/n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1-n2/n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

        if f1 == 2:

            if f2 == 0:

                if f3 == 0:  # n1*n2+n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1*n2+n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1*n2+n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1*n2+n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 1:

                if f3 == 0:  # n1*n2-n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1*n2-n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1*n2-n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1*n2-n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 2:

                if f3 == 0:  # n1*n2*n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1*n2*n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1*n2*n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1*n2*n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 3:

                if f3 == 0:  # n1*n2/n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1*n2/n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1*n2/n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1*n2/n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

        if f1 == 3:

            if f2 == 0:

                if f3 == 0:  # n1/n2+n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1/n2+n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1/n2+n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1/n2+n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 1:

                if f3 == 0:  # n1/n2-n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1/n2-n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1/n2-n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1/n2-n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 2:

                if f3 == 0:  # n1/n2*n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1/n2*n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1/n2*n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1/n2*n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

            if f2 == 3:

                if f3 == 0:  # n1/n2/n3+n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 1:  # n1/n2/n3-n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 2:  # n1/n2/n3*n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

                elif f3 == 3:  # n1/n2/n3/n4

                    result, n1, n2, n3, n4 = four_arithmetic(n1, n2, n3, n4, f1, f2, f3)

    if f == 2:

        with open('subject.txt', 'a') as file0:  # 用with open写入subject.txt

            print(n1, sym[f1], n2, sym[f2], n3, '=', math.floor(result), file=file0)

            print(n1, sym[f1], n2, sym[f2], n3, '=', math.floor(result))

    elif f == 3:

        with open('subject.txt', 'a') as file0:

            print(n1, sym[f1], n2, sym[f2], n3, sym[f3], n4, '=', math.floor(result), file=file0)

            print(n1, sym[f1], n2, sym[f2], n3, sym[f3], n4, '=', math.floor(result))

    return 0


# 3个数的四则运算

def three_arithmetic(n1, n2, n3, f1, f2):

    result = 0

    if f1 == 0:

        if f2 == 0:  # n1+n2+n3

            result = n1 + n2 + n3

        elif f2 == 1:  # n1+n2-n3

            while n1 + n2 < n3:

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 + n2 -n3

        elif f2 == 2:  # n1+n2*n3

            result = n1 + n2 * n3

        elif f2 == 3:  # n1+n2/n3

            while (n2 % n3 != 0) | (n2 < n3):

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 + n2 / n3

    elif f1 == 1:

        if f2 == 0:  # n1-n2+n3

            while n1 + n3 < n2:

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 - n2 + n3

        elif f2 == 1:  # n1-n2-n3

            while n1 < n2 + n3:

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 - n2 - n3

        elif f2 == 2:  # n1-n2*n3

            while n1 < n2 * n3:

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 - n2 * n3

        elif f2 == 3:  # n1-n2/n3

            while (n2 % n3 != 0) | (n2 < n3) | (n1 < n2 / n3):

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 - n2 / n3

    elif f1 == 2:

        if f2 == 0:  # n1*n2+n3

            result = n1 * n2 + n3

        elif f2 == 1:  # n1*n2-n3

            while n1 * n2 < n3:

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

            result = n1 * n2 - n3

        elif f2 == 2:  # n1*n2*n3

            result = n1 * n2 * n3

        elif f2 == 3:  # n1*n2/n3

            while (n2 < n3) | (n2 % n3 != 0):

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 * n2 / n3

    elif f1 == 3:

        if f2 == 0:  # n1/n2+n3

            while (n1 % n2 != 0) | (n1 < n2):

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

            result = n1 / n2 + n3

        elif f2 == 1:  # n1/n2-n3

            while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3):

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 / n2 - n3

        elif f2 == 2:  # n1/n2*n3

            while (n1 < n2) | (n1 % n2 != 0):

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

            result = n1 / n2 * n3

        elif f2 == 3:  # n1/n2/n3

            while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3) | (n1 / n2 % n3 != 0):

                n1 = random.randint(1, 100)

                n2 = random.randint(1, 100)

                n3 = random.randint(1, 100)

            result = n1 / n2 / n3

    return result, n1, n2, n3


# 4个数的四则运算

def four_arithmetic(n1, n2, n3, n4, f1, f2, f3):

    result = 0

    if f1 == 0:

        if f2 == 0:

            if f3 == 0:  # n1+n2+n3+n4

                result = n1 + n2 + n3 + n4

            elif f3 == 1:  # n1+n2+n3-n4

                while n1 + n2 + n3 < n4:

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 + n3 - n4

            elif f3 == 2:  # n1+n2+n3*n4

                result = n1 + n2 + n3 * n4

            elif f3 == 3:  # n1+n2+n3/n4

                while (n3 < n4) | (n3 % n4 != 0):

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 + n3 / n4

        if f2 == 1:

            if f3 == 0:  # n1+n2-n3+n4

                while n1 + n2 + n4 < n3:

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                result = n1 + n2 - n3 + n4

            elif f3 == 1:  # n1+n2-n3-n4

                while n1 + n2 < n3 + n4:

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 - n3 - n4

            elif f3 == 2:  # n1+n2-n3*n4

                while n1 + n2 < n3 * n4:

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 - n3 * n4

            elif f3 == 3:  # n1+n2-n3/n4

                while (n1 + n2 < n3 / n4) | (n3 < n4) | (n3 % n4 != 0):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 - n3 / n4

        if f2 == 2:

            if f3 == 0:  # n1+n2*n3+n4

                result = n1 + n2 * n3 + n4

            elif f3 == 1:  # n1+n2*n3-n4

                while n1 + n2 * n3 < n4:

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 * n3 - n4

            elif f3 == 2:  # n1+n2*n3*n4

                result = n1 + n2 * n3 * n4

            elif f3 == 3:  # n1+n2*n3/n4

                while (n3 < n4) | (n3 % n4 != 0) | (n2 * n3 < n4) | ((n2 * n3) % n4 != 0):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 * n3 / n4

        if f2 == 3:

            if f3 == 0:  # n1+n2/n3+n4

                while (n2 < n3) | (n2 % n3 != 0):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                result = n1 + n2 / n3 + n4

            elif f3 == 1:  # n1+n2/n3-n4

                while (n2 < n3) | (n2 % n3 != 0) | (n1 + n2 / n3 < n4):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 / n3 - n4

            elif f3 == 2:  # n1+n2/n3*n4

                while (n2 < n3) | (n2 % n3 != 0):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                result = n1 + n2 / n3 * n4

            elif f3 == 3:  # n1+n2/n3/n4

                while (n2 < n3) | (n2 % n3 != 0) | (n3 < n4) | (n3 % n4 != 0) | (n2 < n3 * n4) | (n2 % (n3 * n4) != 0):

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 + n2 / n3 / n4

    if f1 == 1:

        if f2 == 0:

            if f3 == 0:  # n1-n2+n3+n4

                while n1 + n3 + n4 < n2 :

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                result = n1 - n2 + n3 + n4

            elif f3 == 1:  # n1-n2+n3-n4

                while n1 + n3 < n2 + n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 + n3 - n4

            elif f3 == 2:  # n1-n2+n3*n4

                while n1 + n3 * n4 < n2:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 + n3 * n4

            elif f3 == 3:  # n1-n2+n3/n4

                while (n1 + (n3 / n4) < n2) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 + n3 / n4

        if f2 == 1:

            if f3 == 0:  # n1-n2-n3+n4

                while n1 + n4 < n2 + n3:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 - n3 + n4

            elif f3 == 1:  # n1-n2-n3-n4

                while n1 < n2 + n3 + n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 - n3 - n4

            elif f3 == 2:  # n1-n2-n3*n4

                while n1 < n2 + n3 * n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 - n3 * n4

            elif f3 == 3:  # n1-n2-n3/n4

                while (n1 < n2 + n3 / n4) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 - n3 / n4

        if f2 == 2:

            if f3 == 0:  # n1-n2*n3+n4

                while n1 + n4 < n2 * n3:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 * n3 + n4

            elif f3 == 1:  # n1-n2*n3-n4

                while n1 < n2 * n3 + n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 * n3 - n4

            elif f3 == 2:  # n1-n2*n3*n4

                while n1 < n2 * n3 * n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 * n3 * n4

            elif f3 == 3:  # n1-n2*n3/n4

                while (n1 < n2 * n3 / n4) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 * n3 / n4

        if f2 == 3:

            if f3 == 0:  # n1-n2/n3+n4

                while (n1 + n4 < n2 / n3) | (n2 < n3) | (n2 % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 / n3 + n4

            elif f3 == 1:  # n1-n2/n3-n4

                while (n1 < n2 / n3 + n4) | (n2 < n3) | (n2 % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 / n3 - n4

            elif f3 == 2:  # n1-n2/n3*n4

                while (n1 < n2 / n3 * n4) | (n2 < n3) | (n2 % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 / n3 * n4

            elif f3 == 3:  # n1-n2/n3/n4

                while (n1 < n2 / n3 / n4) | (n2 < n3) | (n2 % n3 != 0) | (n2 / n3 < n4) | ((n2 / n3) % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 - n2 / n3 / n4

    if f1 == 2:

        if f2 == 0:

            if f3 == 0:  # n1*n2+n3+n4

                result = n1 * n2 + n3 + n4

            elif f3 == 1:  # n1*n2+n3-n4

                while n1 * n2 + n3 < n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 + n3 - n4

            elif f3 == 2:  # n1*n2+n3*n4

                result = n1 * n2 + n3 * n4

            elif f3 == 3:  # n1*n2+n3/n4

                while (n3 < n4) | (n3 % n4 != 0):

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 + n3 / n4

        if f2 == 1:

            if f3 == 0:  # n1*n2-n3+n4

                while n1 * n2 + n4 < n3:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 - n3 + n4

            elif f3 == 1:  # n1*n2-n3-n4

                while n1 * n2 < n3 + n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 - n3 - n4

            elif f3 == 2:  # n1*n2-n3*n4

                while n1 * n2 < n3 * n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 - n3 * n4

            elif f3 == 3:  # n1*n2-n3/n4

                while (n1 * n2 < n3 / n4) | (n3 % n4 != 0) | (n3 < n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 - n3 / n4

        if f2 == 2:

            if f3 == 0:  # n1*n2*n3+n4

                result = n1 * n2 * n3 + n4

            elif f3 == 1:  # n1*n2*n3-n4

                while n1 * n2 * n3 < n4:

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 * n3 - n4

            elif f3 == 2:  # n1*n2*n3*n4

                result = n1 * n2 * n3 * n4

            elif f3 == 3:  # n1*n2*n3/n4

                while (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 * n3 / n4

        if f2 == 3:

            if f3 == 0:  # n1*n2/n3+n4

                while (n2 < n3) | (n2 % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 / n3 + n4

            elif f3 == 1:  # n1*n2/n3-n4

                while (n2 < n3) | (n2 % n3 != 0) | (n1 * n2 / n3 < n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 / n3 - n4

            elif f3 == 2:  # n1*n2/n3*n4

                while (n2 < n3) | (n2 % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 / n3 * n4

            elif f3 == 3:  # n1*n2/n3/n4

                while (n2 < n3) | (n2 % n3 != 0) | (n2 / n3 < n4) | ((n2 / n3) % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 * n2 / n3 / n4

    if f1 == 3:

        if f2 == 0:

            if f3 == 0:  # n1/n2+n3+n4

                while (n1 < n2) | (n1 % n2 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                result = n1 / n2 + n3 + n4

            elif f3 == 1:  # n1/n2+n3-n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 + n3 < n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 + n3 - n4

            elif f3 == 2:  # n1/n2+n3*n4

                while (n1 < n2) | (n1 % n2 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 + n3 * n4

            elif f3 == 3:  # n1/n2+n3/n4

                while (n1 < n2) | (n1 % n2 != 0) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 + n3 / n4

        if f2 == 1:

            if f3 == 0:  # n1/n2-n3+n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 + n4 < n3):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 - n3 + n4

            elif f3 == 1:  # n1/n2-n3-n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3 + n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 - n3 - n4

            elif f3 == 2:  # n1/n2-n3*n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3 * n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 - n3 * n4

            elif f3 == 3:  # n1/n2-n3/n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3 / n4) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 - n3 / n4

        if f2 == 2:

            if f3 == 0:  # n1/n2*n3+n4

                while (n1 < n2) | (n1 % n2 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                result = n1 / n2 * n3 + n4

            elif f3 == 1:  # n1/n2*n3-n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 * n3 < n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 * n3 - n4

            elif f3 == 2:  # n1/n2*n3*n4

                while (n1 < n2) | (n1 % n2 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 * n3 * n4

            elif f3 == 3:  # n1/n2*n3/n4

                while (n1 < n2) | (n1 % n2 != 0) | (n3 < n4) | (n3 % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 * n3 / n4

        if f2 == 3:

            if f3 == 0:  # n1/n2/n3+n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3) | ((n1 / n2) % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 / n3 + n4

            elif f3 == 1:  # n1/n2/n3-n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3) | ((n1 / n2) % n3 != 0) | (n1 / n2 / n3 < n4):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 / n3 - n4

            elif f3 == 2:  # n1/n2/n3*n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3) | ((n1 / n2) % n3 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 / n3 * n4

            elif f3 == 3:  # n1/n2/n3/n4

                while (n1 < n2) | (n1 % n2 != 0) | (n1 / n2 < n3) | ((n1 / n2) % n3 != 0) | (n1 / n2 / n3 < n4) | ((n1 / n2 / n3) % n4 != 0):

                    n1 = random.randint(1, 100)

                    n2 = random.randint(1, 100)

                    n3 = random.randint(1, 100)

                    n4 = random.randint(1, 100)

                result = n1 / n2 / n3 / n4

    return result, n1, n2, n3, n4


n = int(input("出题数量:"))

m = 0

while m <= n-1:

    make_question()

    m = m + 1
