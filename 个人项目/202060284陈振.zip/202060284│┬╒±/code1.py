import random

class Exercise():
    '''
    类说明：练习类
    '''
    def __init__(self, Exercise_Number):
        '''
        方法说明：初始化
        方法参数：Exercise_Number
        方法功能：构建该类对象的同时确定练习题的题目数
        '''
        self.Exercise_Number = Exercise_Number

    def Create_Exercise(self):
        '''
        方法说明：创建练习题
        方法参数: 无
        方法功能：确定练习题目中二元运算符和三元运算符各自的题目数（默认规则：一题二元一题三元）
        '''
        while self.Exercise_Number > 0:
            if self.Exercise_Number % 2 == 0:
                self._Create(2)           #二元运算
            elif self.Exercise_Number % 2 == 1:
                self._Create(3)           #三元运算
            self.Exercise_Number -= 1
        print("出题完成")

    def _Create(self,Operator_Number):
        '''
        方法说明：创建表达式并保存文档
        方法参数： Operator_Number
        方法功能: 根据运算符的个数创建对应的计算表达式，并保存到相应.txt文件下
        '''
        operator = ["+", "-", "*", "/"]
        temp1 = 100
        a = int(random.uniform(1, 99))
        expression = "" + str(a)
        while Operator_Number > 0:
            seed = int(random.uniform(0, 3.99))
            if operator[seed] == "/":
                if temp1 == a:
                    b = int(random.uniform(1, a))     #根据先验条件进行除数优化
                    while a % b != 0:
                        b = int(random.uniform(1, a))
                    temp1 = temp1 / b
                else:
                    b = int(random.uniform(1, a))
                    while a % b != 0:
                        b = int(random.uniform(1, a))
                    temp1 = a / b
            else:
                b = int(random.uniform(1, 99))
                if operator[seed] == "+":
                    temp1 = b
                elif operator[seed] == "-":
                    temp1 = b
                elif operator[seed] == "*":
                    temp1 = a * b
            expression += operator[seed] + str(b)
            a = temp1
            Operator_Number -= 1
        print(expression + " = " +  str(int(eval(expression))))                   #输出相应的计算表达式
        data = open("C:\\Users\\ASUS\\Desktop\\pythoncode\\subject.txt","a")      #选择输出的文件地址与模式
        data.write(expression + " = " +  str(int(eval(expression))) + "\n")
        data.close()


if __name__ == "__main__":
    while True:
        try:                                       #避免误输入的异常处理
            Num = input("请输入口算练习题目数：")
            Num = int(Num)
        except Exception:
            print("请输入正确的题目数!!!")
        else:
            e = Exercise(Num)
            e.Create_Exercise()
            break
