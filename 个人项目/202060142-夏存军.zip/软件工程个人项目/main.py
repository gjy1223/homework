import KouSuan
TiMu = open("subject", "a")
# 判断输入的是否是整数数字，如果不是提示用户重新输入
while True:
    # noinspection PyBroadException
    try:
        ShuLiang = int(input('请输入题目数量'))
    except Exception as fault:
        print("请输入正确的题目数量")
        continue
    break
while True:
    Num = KouSuan.creat_num()
    Symbol = KouSuan.creat_symbol()
    Formula = KouSuan.mix_str()
    if type(eval(Formula)) == int:
        TiMu.write(Formula)
        TiMu.write("=")
        TiMu.write(str(eval(Formula)))
        TiMu.write("\n")
        ShuLiang = ShuLiang - 1
    else:
        continue
    if ShuLiang == 0:
        break
TiMu.close()
