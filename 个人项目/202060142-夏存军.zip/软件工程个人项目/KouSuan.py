import random
count = 0
symbol_list = ["+", "-", "*", "/"]
num = []
symbol = []


# 生成随机3-4个数字
def creat_num():
    num.clear()
    global count
    count = random.randint(3, 4)
    for i in range(0, count):
        t = str(random.randint(0, 100))
        num.append(t)
    # print(num)
    return num


# 根据生成的随机数的个数，随机生成相应个数的运算符
def creat_symbol():
    symbol.clear()
    for i in range(1, count):
        y = random.randint(0, 3)
        symbol.append(symbol_list[y])
    if __name__ == "__main__":
        print(symbol)
    return symbol


# 将生成的数字和运算符整合为一个表达式字符串
def mix_str():
    for i in range(1, count):
        num.insert(2*i-1, symbol[i-1])
    result = "".join(num)
    # print(result)
    return result


if __name__ == "__main__":
    creat_num()
    creat_symbol()











