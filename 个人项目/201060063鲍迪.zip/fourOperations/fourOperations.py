import numpy as np
import random
import sys


def main():
    s = sys.argv[1]

    num = int(s)  # 将输入的数字从string转为int

    file_handle = open('subject.txt', mode='w')  # 打开txt文件
    for i in range(num):
        dict1 = {'1': '+', '2': '-', '3': '*', '4': '/'}
        while 1:  # 使生成的算式结果为整数，用if判断，是则break
            symbolNum = random.randrange(2, 4)  # 生成运算符的个数
            number1 = random.randrange(1, 100)  # 生成1-99之间的随机数4个
            number2 = random.randrange(1, 100)
            number3 = random.randrange(1, 100)
            number4 = random.randrange(1, 100)
            symbol = np.arange(1, 5)  # 生成1-4之间的乱序列表，用来和字典连锁生成运算符
            np.random.shuffle(symbol)
            if symbolNum == 2:  # 生成对应运算符的算式
                formula = str(number1) + dict1[str(symbol[0])] + str(number2) + dict1[str(symbol[1])] + str(number3)
            else:
                formula = str(number1) + dict1[str(symbol[0])] + str(number2) + dict1[str(symbol[1])] + str(number3) + \
                          dict1[str(symbol[2])] + str(number4)

            if isinstance(eval(formula), int):
                print(symbol)
                break
        print(formula, '=', eval(formula))
        file_handle.write(formula + ' = ' + str(eval(formula)) + '\n')  # 将结果输出到txt文件
    file_handle.close()  # 关闭文件


if __name__ == '__main__':
    main()
