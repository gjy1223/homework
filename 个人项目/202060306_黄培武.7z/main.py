import random
import os
import time,datetime

operator_list = ['+','-','*','/']

def calculator():

    while(True):
        num_operator = random.randint(2,3)  #随机选择是2个还是3个运算符
        question = random.randint(0, 100)
        question = str(question)
        for i in range(num_operator):
            operator = random.randint(0,3)
            if (question[-1]=="/"):   #除法后面不能接0
                number = random.randint(1, 100)
            else:
                number = random.randint(0,100)

            question += operator_list[operator]
            question += str(number)

        output = float(eval(question))
        if output.is_integer():
            output = int(output)
            break
    question += "=" + str(output)
    #question = question.replace('/','÷')   #需要用GBK编码格式打开
    #question = question.replace('*', 'x')
    return question


def main():
    if not os.path.exists('./计算题'):
        os.mkdir('./计算题')
    save_path = datetime.datetime.now().isoformat()[:-7]
    save_path = save_path[:10] + '---' + save_path[11:]
    save_path = save_path.replace(':','-')+'.txt'


    print("您好,欢迎使用口算出题器！")
    num = input("请问要出几道题目呢？\n")
    for i in range(int(num)):
        question = calculator()
        with open(os.path.join('./计算题', save_path), 'a') as f:
            f.write(question+'\n')


if __name__ == '__main__':
    main()


