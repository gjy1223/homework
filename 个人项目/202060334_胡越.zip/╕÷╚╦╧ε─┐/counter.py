import numpy as np
import random


def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def div(a, b):
    return a / b

def mul(a, b):
    return a * b

#求某一整数的约数
def allFactor(n):
    if n == 0: return [0]
    if n == 1: return [1]
    rlist = []
    for i in range(1,n+1):
        if n%i == 0:
            rlist.append(i)
    return rlist


def counter():
    num_operator = int(np.random.randint(2, 4, 1))  #运算符数目，随机为2或者3
    m = ['+', '-', '*', '/','+', '-', '*', '/']
    operator = []#用于存放运算符的列表
    operator=random.sample(m, num_operator)
    operator_copy = operator.copy()  # operator_copy最后用于显示在屏幕上的运算符列表
    numbers= list(np.random.randint(1, 100, size=(int(num_operator + 1))))  # 生成3-4个100以内的随机整数
    numbers_copy = numbers.copy()  # numbers_copy最后用于显示在屏幕上的数字列表
    print(operator)
    print(numbers)
    # 除法运算符
    i = 0
    while '/' in operator:
        for index, nums in enumerate(operator):
            if nums == '/':
                if numbers[index+1]==0:#当分母为零时，改变分母（直接加一）
                    numbers[index+1]+=1
                    numbers_copy[index+1+i]=numbers[index+1]
                    #i指已经遍历过除号的次数，由于operator和numbers会不断删掉除号和被除数，于是改变operator_copy时，需要加上i才能对应正确的索引
                div_answer = div(numbers[index], numbers[index+1])
                if ((div_answer!=0) and (div_answer%int(div_answer)!=0)):#如果结果是非整数，需要调整被除数
                    list_yueshu=allFactor(int(numbers[index]))#约数列表
                    k = random.sample(list_yueshu, 1)#k是某一约数
                    k=int(k[0])#由于生成的k是列表形式，取k值则需要取k[0]
                    numbers_copy[index+1+i] = int(k)  #修改numbers_copy中对应的被除数为除数的某一约数
                    i += 1#i指已经遍历过除号的次数，次数加一，主要是为存在多个除号的现象而准备
                    numbers[index+1] = div(numbers[index], k)
                else:
                    i += 1
                    numbers[index+1] = div_answer
                del numbers[index]
                del operator[index]
                break

    while ('*' in operator):
        i = operator.index('*')  # 运算符list里面乘号的索引
        mul_answer = numbers[i]
        mul_answer = mul(mul_answer, numbers[i + 1])
        del operator[i]
        numbers[i] =mul_answer
        del numbers[int(i + 1)]

    operator2 = operator.copy()
    for i in range(len(operator2)):
        if operator2[i] == '+':
            i = operator.index('+')  # 运算符list里面乘号的索引
            ans = numbers[i]
            ans = add(ans, numbers[i + 1])
            del operator[i]
            numbers[i] = ans
            del numbers[int(i + 1)]
            continue
        if operator2[i] == '-':
            i = operator.index('-')  # 运算符list里面乘号的索引
            ans = numbers[i]
            ans = sub(ans, numbers[i + 1])
            del operator[i]
            numbers[i] = ans
            del numbers[int(i + 1)]
            continue

    question = []
    question.append(str(numbers_copy[0]))
    for i in range(len(operator_copy)):
        question.append(str(operator_copy[i]))
        question.append(str(numbers_copy[i + 1]))
    d = ""
    for j in question:
        d += j
    c=d
    d+="="
    d+=str(int(numbers[0]))
    if eval(c)==numbers[0]:
        return d

if __name__ == '__main__':
    a=input("计算题个数：")
    f = open("11.txt", "w+")
    for i in range(int(a)):
        d=counter()
        f.write(d+'\n')
