#!/usr/bin/env python
# coding: utf-8

# In[1]:


import random
import os
import copy
symbol = ["+","-","*","/"]
nums = random.randint(3,4)

#生成随机数
def generate_nums():
    global nums
    num_list = []
    for i in range(nums):
        num_list.append(str(random.randint(0,50)))
    return num_list

#生成随机符号
def generate_symbol():
    symbol_list = []
    for i in range(nums-1):
        symbol_list.append(symbol[random.randint(0,3)])
    return symbol_list

#生成表达式
def mix_nums():
    while True: 
        symbol_list = generate_symbol()
        num_list = generate_nums()
        full_exp_list = copy.deepcopy(num_list)
        for i in range(nums-1):
            full_exp_list.insert(2*i+1, symbol_list[i])
            result = "".join(full_exp_list)
        break      
    return result,symbol_list,num_list,full_exp_list

#求公因数
def pub_ele(num):
    list = []
    if num == 1 or num == 0:
        list = [1]
    else:
        for i in range(1,num):
            if num % i == 0:
                list.append(i)
    return list


#找出所有索引
def find_all_index(li,obj):
    obj_list = []
    for i in range(len(li)):
        if li[i] == obj:
            obj_list.append(i)
    return obj_list

#按照要求筛选表达式(除法筛选)
def check_res():
    result,symbol_list,num_list,full_exp_list = mix_nums()

    res_list = list(result)
    if '/' in symbol_list:
        obj_list = find_all_index(symbol_list,"/")                   #对除号后每个数字取被除数的公因数    
        for i in obj_list:
            num_list[i+1] = str(random.choice(pub_ele(int(num_list[i]))))

        full_exp_list = copy.deepcopy(num_list)  
        for i in range(len(symbol_list)):                            #再次将数字符号完整插入形成完整表达式
            full_exp_list.insert(2*i+1, symbol_list[i])
            result = "".join(full_exp_list)
        res_list = list(result)
        value_res = str(int(eval("".join(res_list))))
        final_res = "".join(res_list) + '=' + value_res
    else:
        value_res = str(int(eval("".join(res_list))))
        final_res = "".join(res_list) + '=' + value_res
    
    return final_res,value_res   

#限制结果大小
def limit_res_value():
    while True:
        final_res,value_res = check_res()
        if int(value_res) < 1000:
            break
        else:
            continue
    return final_res


#输出所需txt文件
def generate_file():
    if not os.path.exists("./math_test"):
        os.mkdir("./math_test")
    try:
        cal_nums = int(input('请输入练习题目数：'))
    except Exception as fault:  
        print("请输入正确的练习题目数")
    filename = "math_quzi.txt"
    dataPath = "./math_test/" + filename
    
    
    with open(dataPath,'w') as fp:
        for i in range(cal_nums):
            exp = limit_res_value().replace('/','÷')
            fp.write(exp)
            fp.write('\n')
    print('成功生成%d道题目！' %cal_nums)
    
if __name__ == '__main__':
    generate_file()

