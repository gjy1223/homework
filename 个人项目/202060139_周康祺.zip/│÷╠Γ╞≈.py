import random
import sys

#运算符存在相同
def getOperator(a):
    #运算符字典
    operator_dic = {0:"+",  1: "-", 2: "*", 3: "/"}
    #operator_num = random.randint(0, 3)
    receive_op = []
    flag = True
    while(flag):
        op = random.randint(0, 3)
        receive_op.append(operator_dic[op])
        if(len(receive_op) < a):
            flag = True
        elif(len(receive_op) == a):
            flag = False
            return receive_op

#随机生成相应数字，个数 = 运算符+1个
def get_nums(a):
    opertor_length = a
    nums = []
    for i in range(opertor_length+1):
        nums.append(random.randint(0, 100))
    return nums

#初始化得到数字和运算符列表
def initStr():
    a = random.randint(2, 3)
    signs = getOperator(a)
    nums = get_nums(a)
    
    inStr = []
    for i in range(len(signs)):
        inStr.append(nums[i])
        inStr.append(signs[i])
    inStr.append(nums[len(signs)])
    return inStr

#判断是否是整数
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
 
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False

def calculate(instr):

    def jia(stack, num):
        stack.append(num)
        

    def jian(stack, num):
        stack.append(- num)

    def cheng(stack, num):
        pre = stack.pop()
        stack.append(pre * num)

    def chu(stack, num):
        pre = stack.pop()
        stack.append(pre / num)
    
    operator = {'+':jia,'-':jian,'*':cheng,'/':chu}
    
    def f(stack, o, num):
        operator.get(o)(stack, num)
    
    stack = []
    num = 0
    sign = '+'    #记录 num 前的符号，初始化为 +
    
    for i in range(len(instr)):
        c = instr[i]
        #如果是数字，读取到num
        if(is_number(c)):
            num = c
        #如果不是数字，就是遇到了下一个符号，
        #之前的数字和符号就要存进栈中
        is_sign = bool(1 - is_number(instr[i]))
        if(is_sign or i == len(instr) - 1):
            f(stack, sign, num)
            #更新符号位当前符号，数字清零
            sign = c
            num = 0
    res = 0
    while(len(stack) > 0):    #把得到的stack中每个元素相加
        res += stack.pop()
    return res

def main(x):
    #初始化
    
    resdic = {}  #以字典类型保存X个结果
    for j in range(x):
        res = ''
        instr = initStr()
        result = calculate(instr)

        while((result - int(result)) != 0):
            instr = initStr()
            result = calculate(instr)
    #     return instr, result
        for i in range(len(instr)):
            res += (str(instr[i]) + ' ')
        res += ('= ' + str(result))
        resdic[str(j)] = res
    return resdic

#main(5)

dic_cal = {}
n = input("请输入：")
print(n)
x = int(n)
dic_cal = main(x)

f = open("E:/letusgo/test/calculator.txt", "w")
for i in range(x):
    f.write( dic_cal[str(i)] + "\n" )

f.close()


