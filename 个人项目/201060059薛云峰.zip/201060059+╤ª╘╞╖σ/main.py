"""
软件的需求：
•	程序接收一个命令行参数 n，然后随机产生 n 道加减乘除（分别使用符号+-*/来表示）练习题，每个数字在 0 和 100 之间，运算符在2个 到 3 个 之间。
•	由于阿超的孩子才上一年级，并不知道分数所以软件所出的练习题在运算过程中不得出现非整数，比如不能出现 3÷5+2=2.6 这样的算式。
•	练习题生成好后，将生成的n道练习题及其对应的正确答案输出到一个文件 subject.txt 中。
•	当程序接收的参数为4时，以下为一个输出文件示例。
13+17-1=29
11*15-5=160
3+10+4-16=1
15÷5+3-2=4
"""
import random

operators = ['+', '-', '*', '/']

def genarateSingleEqu() :
    """
    随机生成一个等式
    :return: eq    ：等式的字符串
            int_res: 等式的结果
    """
    num_of_operator = random.randint(2, 3)   # 运算符数量
    # print('运算符数量：{}'.format(num_of_operator))
    isGenerating = True
    while (isGenerating):
        '''
        开始生成
        '''
        equation = []  # 储存生成的的等式

        # 操作数数量 = 运算符数量+1;
        # range默认从0开始不包括stop
        for i in range(num_of_operator * 2 + 1):
            # print(i)
            if i % 2 == 0:
                equation.append(str(random.randint(1, 100)))  # 不包含0因为除以0会出错
                # print(equation)
            else:
                equation.append(random.choice(operators))  # 随机选取操作符
                # print(equation)

        eq = ''.join(equation)
        res = eval(eq)  # 计算结果
        int_res = int(res)
        if (res - int_res == 0) and res >= 0:          # 一年级还没学负数因此结果不应该大于0
            return eq, int_res

def genarateSubject(n, f) :
    """
    :param n: 要生成的题目总数
    :param f: 保存题目的文件指针
    :return: 无
    """
    equations = []
    for i in range(n):
        eq, res = genarateSingleEqu()
        eq = str(i + 1) + '. ' + eq + ' = ' + str(res) + '\n'  # 符合要求，生成完整的等式
        equations.append(eq)
        print(eq)
        i += 1

    # 写入文件
    f.writelines(equations)



if __name__ == '__main__':

    # 目标等式数量
    print("#########################################")
    n = input("请输入想要的等式数量:")
    n = int(n)
    print("#########################################")

    with open("subject.txt", 'w') as f:
        '''
        生成n个等式，并保存在文件中
        '''
        genarateSubject(n, f)


