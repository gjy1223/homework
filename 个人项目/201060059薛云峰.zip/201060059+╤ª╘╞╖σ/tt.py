
def subarraysDivByK(A, K):
    """
    :type A: List[int]
    :type K: int
    :rtype: int
    """
    dic = {}
    # 初始化一个字典
    for i in range(K):
        dic[i] = 1 if i == 0 else 0
    for i in range(1, len(A)):
        A[i] += A[i - 1]
    for a in A:
        dic[a % K] += 1
    return sum(v * (v - 1) // 2 for v in dic.values())

if __name__ == '__main__':
    A = [1,5,2,4,3,17]
    k = 6
    an = subarraysDivByK(A, k)
    print(an)
