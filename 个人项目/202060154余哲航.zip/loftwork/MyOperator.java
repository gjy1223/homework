package com.Yu.loftwork;
import java.util.ArrayList;


abstract class MyOperator {
	int MAX = 1000;
	char oper;
	MyOperator(){oper = 'A';}
	abstract int nextNum(int lastNum);
}

class MyAdd extends MyOperator{
	char oper = '+';
	@Override
	int nextNum(int lastNum) {
		return (int)Math.random()*MAX;
	}
	
}
class MySub extends MyOperator{
	char oper = '-';
	@Override
	int nextNum(int lastNum) {
		return (int)Math.random()*MAX;
	}
	
}
class MyMul extends MyOperator{
	char oper = '*';
	@Override
	int nextNum(int lastNum) {
		return (int)Math.random()*MAX;
	}
	
}
class MyDiv extends MyOperator{
	char oper = '/';
	ArrayList<Integer> myArray = new ArrayList<Integer>();
	int nextNum(int lastNum) { //已知被除数，得到除数
		myArray.clear();
		for(int i = 1;i < lastNum + 1;i++){
			if(lastNum % i == 0){
				myArray.add(i);
			}
		}
		if(myArray.size()>0)
		{
			int num = (int)(Math.random()*myArray.size());
			return myArray.get(num);
		}
		return (int)(Math.random()*MAX + 1);
		
	}
	int getNextNum(MyOperator A,int lastNum)
	{
		return A.nextNum(lastNum);
	}

}