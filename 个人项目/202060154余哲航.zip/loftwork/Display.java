package com.Yu.loftwork;

import java.io.IOException;

public class Display {
  public static void main(String[] args) throws IOException {
	Counter counter = new Counter();
	try {
		counter.getQustNum();
		counter.getQust();
	} catch (Exception e) {
		e.printStackTrace();
	}
  }
}
