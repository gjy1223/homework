package com.Yu.loftwork;
import java.util.Scanner;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Counter {
	int qustNum = 0; 
	char oper[] = {'+','-','*','/'};
	ArrayList<Integer> operatorList = new ArrayList<Integer>();
	ArrayList<Integer> numList = new ArrayList<Integer>();
	int operatorNum = 0;
	MyDiv myDiv = new MyDiv();//定义除法器
	int answer = 0;
	
	//用于得到问题的个数
	void getQustNum(){
		int num = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入题目数：");
		while(true){	
			num = scanner.nextInt();
			if(num>0){
				qustNum = num;
				System.out.println("输入的数为:"+num);
				break;				
			}
			else{
				System.out.println("输入的范围大于0，请重新输入");
			}
		}
		scanner.close();
	}
	
	//显示操作符
	char show(int i)
	{
		return oper[i];
	}
	//显示问题并写入
	void showQust() throws IOException
	{
		String Qust = new String();
		File file = new File("subject.txt");	
		FileWriter fw = new FileWriter(file,true);
		for(int i = 0;i < operatorNum;i++)
		{
			Qust = Qust + numList.get(i);
			Qust = Qust + show(operatorList.get(i));
		}
		Qust = Qust + numList.get(operatorNum);
		Qust = Qust + "="+getAnswer()+'\n';
		fw.write(Qust);
		System.out.print(Qust);
		fw.close();
	}
	
	//得到算式的答案
	int getAnswer() 
	{
		int temp = 0;
		for(int i = 0;i < operatorNum;) //把*/计算答案算出
		{
			if(operatorList.get(i)==2)
			{
				temp = numList.get(i) * numList.get(i+1);
				numList.set(i, temp);
				numList.remove(i+1);
				operatorList.remove(i); // 去掉此运算符
				operatorNum--;
				continue;
			}
			if(operatorList.get(i)==3)	
			{
				temp = numList.get(i) / numList.get(i+1);
				numList.set(i, temp);
				numList.remove(i+1);
				operatorList.remove(i);
				operatorNum--;
				continue;
			}
			i++;
		}
		for(int i = 0;i < operatorNum;) // 将+ - 答案算出
		{
			if(operatorList.get(i)==0)
			{
				temp = numList.get(i) + numList.get(i+1);
				numList.set(i,temp);
				numList.remove(i+1);
				operatorList.remove(i);
				operatorNum--;
				continue;
			}
			if(operatorList.get(i)==1)
			{
				temp = numList.get(i) - numList.get(i+1);
				numList.set(i,temp);
				numList.remove(i+1);
				operatorList.remove(i);
				operatorNum--;
				continue;
			}
		}
		return numList.get(0);
	}
	
	
	//得到N个算式(不包括答案）
	void getQust() throws IOException 
	{
		File file = new File("subject.txt");	
		FileWriter fw1 = new FileWriter(file);
		fw1.close();
		for(int j = 0;j < qustNum; j++)
		{
			operatorNum = (int)(Math.random()*2+2); // 2-3
			numList.add((int)(Math.random()*100)); //添加第一个数
			for(int i = 0;i < operatorNum;i++) //添加其他所有的运算符和数字
			{
				numList.add((int)(Math.random()*100));
				operatorList.add((int)(Math.random()*4));//0-3 代表四个运算符
			}
			int lastNum = numList.get(0);//就是前一个数字或前一个*/运算出的值
			for(int i = 0;i < operatorNum;i++)
			{
				if(operatorList.get(i) <= 1)			
					lastNum = numList.get(i+1);
				if(operatorList.get(i) == 2)
				{
					lastNum = lastNum * numList.get(i+1); //如果乘法 lastNum用积代替
				}
				if(operatorList.get(i) == 3)
				{					
					numList.set(i+1,myDiv.nextNum(lastNum)); //除法运算器将/后的值修改
					lastNum = lastNum / numList.get(i+1);
				}
			}
			showQust(); // 显示算式
			numList.clear();
			operatorList.clear();
		}
	}
	
	
}
