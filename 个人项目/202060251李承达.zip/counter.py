import random

file=open("口算记题器.txt","a+")
n=input("请输入题目数量：")
number=int(n)
op=['+','-','*','/']
q=[]
r=[]
j=0


#生成随机运算符
def get_op():
    i=random.randint(0,3)
    if i==0:
        return "+"
    elif i==1:
        return "-"
    elif i==2:
        return "*"
    else:
        return "/"


while j<number:
    first=random.randint(0,100)
    second=random.randint(0,100)
    third=random.randint(0,100)
    fourth=random.randint(0,100)
    op1=get_op()
    op2=get_op()
    op3=get_op()
    

#根据运算符个数生成算术式子
    type=random.randint(1,2)
    if type==1:
        question="%s %s %s %s %s"%(first,op1,second,op2,third)
        #防止出现除数为0的情况
        if (op1=="/" and second==0) or (op2=="/" and third==0):
            continue
        #防止出现商出现小数
        elif (op1=="/" and int(first/second)!=(first/second)) or (op2=="/" and int(second/third)!=(second/third)):
            continue
        
    else:
        question="%s %s %s %s %s %s %s"%(first,op1,second,op2,third,op3,fourth)
        if (op1=="/" and second==0) or (op2=="/" and third==0) or (op3=="/" and fourth==0):
            continue
        elif (op1=="/" and int(first/second)!=(first/second)) or (op2=="/" and int(second/third)!=(second/third)) or (op3=="/" and int(third/fourth)!=(third/fourth)):
            continue
    #将数学表达式字符转化为表达式，且计算并返回计算结果
    result=int(eval(question))
    ret=str(result)
    #防止最后结果出现小数
    if result<=0 or int(result)!=result or result>100:
        continue
    q.append(question)
    r.append(ret)
  
    file.writelines(q[j]+"="+r[j]+"\n")
    
    j+=1
    

file.close()

    



       
    

        
        

