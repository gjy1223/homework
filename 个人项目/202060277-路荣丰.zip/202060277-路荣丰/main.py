
import random
operation_list = ['+', '-', '*', '/']                                       #四则运算的符号列表
global expression                                                           #初始化计算表达式
global num_practice
def Calculate():
    num_with_operator = random.randint(1, 2)                                #随机后面可以带符号的数字的个数
    expression = ''
    for i in range(num_with_operator):                                      #随机选择后面可以带符号的数字其中具体的符号和数字
        digital_ = random.randint(1, 100)                                   #随机选择数字
        operator = operation_list[random.randint(0, 3)]                     #随机选择运算符
        expression += str(digital_) + operator                              #更新表达式
    digital_last = random.randint(1, 100)                                   #随机选择表达式中最后的数字
    expression += str(digital_last)                                         #跟新表达式
    answer_true = eval(expression)                                          #自动计算表达式的计算结果
    if int(answer_true) % answer_true == 0:                                 #判断式子的计算结果是否为正数（小孩还没学过小数）
        answer_true = int(answer_true)
    if isinstance(answer_true, int) and answer_true > 0:                    #和小孩进行人机交互
        print('题目：')
        print(expression, '=')
        print('请输出答案：')
        answer_child = eval(input())                                        #小孩输入的结果
        if answer_true == answer_child:
            print('回答正确')
        else:
            print('回答错误')
            print('正确的答案为：', answer_true)
    else:
        Calculate()

def CalculateDivision():
    expression = ''
    digital_one = random.randint(1, 100)
    digital_two = random.randint(1, 100)
    expression = str(digital_one) + '/' + str(digital_two)
    answer_true = eval(expression)
    if answer_true.is_integer():
        print('题目：')
        print(expression, '=')
        print('请输出答案：')
        answer_child = eval(input())
        if answer_true == answer_child:
            print('回答正确')
        else:
            print('回答错误')
            print('正确的答案为：', answer_true)
    else:
        CalculateDivision()

def GenerateTxt():
    num_with_operator = random.randint(1, 2)                                #随机后面可以带符号的数字的个数
    expression = ''
    for i in range(num_with_operator):                                      #随机选择后面可以带符号的数字其中具体的符号和数字
        digital_ = random.randint(1, 100)                                   #随机选择数字
        operator = operation_list[random.randint(0, 3)]                     #随机选择运算符
        expression += str(digital_) + operator                              #更新表达式
    digital_last = random.randint(1, 100)                                   #随机选择表达式中最后的数字
    expression += str(digital_last)                                         #跟新表达式
    answer_true = eval(expression)                                          #自动计算表达式的计算结果
    if int(answer_true) % answer_true == 0:                                 #判断式子的计算结果是否为正数（小孩还没学过小数）
        answer_true = int(answer_true)
    if isinstance(answer_true, int) and answer_true > 0:                    #将表达式记录到.txt中
        with open('subject.txt', 'a') as subject:
            subject.write(expression)
            subject.write('=')
            subject.write(str(answer_true))
            subject.write('\n')
    else:
        GenerateTxt()


if __name__ == '__main__':
    while True:
        print('暑假每日练习：')
        print('输入　１　开始在线练习')
        print('输入　２　除法专项在线练习')                                  #由于没有小数的要求，会使得除法出现的概率极低，所以专门提供一个除法运算的接口
        print('输入　３　生成.txt练习题目')
        print('输入　０　退出系统')
        print('请输入：')
        mode = int(input())
        if mode == 1:
            print('请输入本次练习题目数量：')
            num_practice = int(input())
            print('本次练习数目：', num_practice)
            for j in range(0, num_practice):
                Calculate()

        if mode == 2:
            print('除法练习题目数量：')
            num_practice = int(input())
            print('除法练习数目：', num_practice)
            for j in range(0, num_practice):
                CalculateDivision()

        if mode == 3:
            print('请输入文本中练习题的数目：')
            num_practice = int(input())
            print('文本中练习题的数目：', num_practice)
            with open('subject.txt', 'w') as subject:
                subject.write('每日一练\n')
            for j in range(0, num_practice):
                GenerateTxt()


        elif mode == 0:
            exit()
        else:
            print('请重新输入你的选择')

#isinstance(1, int)
