import random

def writeEquation(equation):
    with open('./equations.txt', 'a') as file:
        file.writelines(equation)

def addEquationAndGetNum(equation, signIndex, numStack=None):
    if signIndex == 3:
        divisors = []
        for d in range(1, 101):
            if numStack[-1] % d == 0:
                divisors.append(d)
        num = divisors[random.randint(0, len(divisors) - 1)]
        equation.append('÷')
        equation.append(str(num))
    else:
        num = random.randint(0, 100)
        equation.append(signs[signIndex])
        equation.append(str(num))
    return num

def createEquation():
    equation=[]
    numStack=[]
    num=random.randint(0,100)
    equation.append(str(num))
    numStack.append(num)
    signNum = random.randint(2, 3)
    for i in range(signNum):
        signIndex = random.randint(0, 3) # +,-,*,/
        if signIndex==0:
            num=addEquationAndGetNum(equation,signIndex)
            numStack.append(num)
        elif signIndex==1:
            num=addEquationAndGetNum(equation,signIndex)
            numStack.append(-num)
        elif signIndex==2:
            num=addEquationAndGetNum(equation,signIndex)
            numStack.append(numStack.pop()*num)
        else:
            num=addEquationAndGetNum(equation,signIndex,numStack)
            numStack.append(numStack.pop() // num)
    ans=0
    for num in numStack:
        ans+=num
    equation.append('='+str(ans)+'\n')
    writeEquation(equation)

if __name__=="__main__":
    n=input()
    signs=['+','-','*','÷']
    for i in range(int(n)):
        createEquation()
