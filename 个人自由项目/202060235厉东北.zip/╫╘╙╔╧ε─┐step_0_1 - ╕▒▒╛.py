stop_words=['a','it','the','and','that','s']
punctuation=[',',' ','\n','"','.',"'",':',')','(',"-","1",'2','3','4','5','6','7','8','9']
frequency={}#字典形式存储未重复母/单词,内有个数
frequency2=[]#列表形式存储未重复字母/单词
file=open('subject2.txt',mode='r')
cg_file=open('cigen.txt',mode='r')
cg_file_2=[]
def stepone(w):
    global lenth#出现字母总次数
    lenth=0
    if w=='2':
        f=file.read()
        for each_letter in f:
            if each_letter not in punctuation:
                each_letter=each_letter.lower()
                if each_letter not in  frequency2:
                   frequency2.append(each_letter)
                
                if each_letter not in frequency:
                    frequency[each_letter]=1
                    lenth+=1
                else:
                   frequency[each_letter]+=1
                   lenth+=1
    else:
        temp=[]
        for each_letter in file:
            each_letter=each_letter.lower()
            for j in punctuation:
                while j in each_letter:
                    each_letter=each_letter.replace(j,'/')
                    
            temp.extend(each_letter.split("/"))
            #print (temp)
            
            for jj in stop_words:
                #这里是停词表
                while jj in temp:
                    temp.pop(temp.index(jj))               
            
        for cg_file_1 in cg_file:
            #这里是转换词根
            cg_file_2=[]
            cg_file_1=cg_file_1.replace('\n',' ')
            cg_file_2.extend(cg_file_1.split(" "))
            for each in  temp:
                if each != '' :
                    if each in cg_file_2:
                        temp[temp.index(each)]=cg_file_2[0]
                    
        for each in  temp:
            if each != '' :
                    if each not  in frequency2 :
                        frequency2.append(each)                    
                    if each not in frequency:                       
                        frequency[each]=1
                        lenth+=1
                    else:
                       frequency[each]+=1
                       lenth+=1    
       
        
def stepone_sort(n=None):
    temp=''
    ss=''
    a=0
    for i in range(len(frequency2)):
       for each in range(len(frequency2)-1):
          if   frequency[frequency2[i]]>frequency[frequency2[each]]:            
             #个数比较
             temp=frequency2[i]
             frequency2[i]=frequency2[each]
             frequency2[each]=temp
          elif frequency[frequency2[i]]==frequency[frequency2[each]]:
             if w=='2':
                 if  ord (frequency2[i])<ord (frequency2[each]):
                    temp=frequency2[i]
                    frequency2[i]=frequency2[each]
                    frequency2[each]=temp
             else:
                 if ord (frequency2[i][0])<ord (frequency2[each][0]):
                    temp=frequency2[i]
                    frequency2[i]=frequency2[each]
                    frequency2[each]=temp
    
    for j in frequency2[:n]:
       ff=frequency[j]/lenth
       ss+="%s的出现频率是%.2f"%(j,ff*100)+'%'+'\n'    
    print (ss+"(已经按从大到小排序)")


#mian
w=input('''请输入查看模式, 单词模式请按1  字母模式请按2:''')
#n=int(input("目标输出前多少个："))
stepone(w)
stepone_sort()

file.close()




