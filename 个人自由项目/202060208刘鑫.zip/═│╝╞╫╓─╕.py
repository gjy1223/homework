import re
import collections
data = open("D:/天池/二手车预测数据/words.txt").read()  #读取文本文件
print(data)
zimu=re.findall(r'{}'.format(input('请输入你想要的的字母或单词：')),data)
print(zimu)
print(len(zimu))
print('-------------------')
danci=re.findall(r'\b[A-z]*\b',data)  # *是重复前面正则，\b是用来分界字母跟空格
print(danci)  #除单词外还有空格
chundanci=[danci[i] for i in range(0,len(danci)) if danci[i]!=""]
print(chundanci)
e=chundanci.count('is')
print(e)
num_Count=collections.Counter(chundanci)
print(num_Count)