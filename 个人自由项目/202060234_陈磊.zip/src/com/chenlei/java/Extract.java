package com.chenlei.java;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @author chenlei
 * @create 2021-03-29-8:43
 */
public class Extract {


    /**
     * map容器降序号排序
     *
     * @param map
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V extends Comparable<? super V>> Map<K, V> sortByValueDescending(Map<K, V> map) {
        List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            @Override
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                int compare = (o1.getValue()).compareTo(o2.getValue());
                return -compare;
            }
        });

        Map<K, V> result = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /**
     * 通过停词表记录词的的个数
     */
    public static void stop_word() {
        FileReader f1 = null;
        FileReader f2 = null;
        BufferedReader b1 = null;
        BufferedReader b2 = null;
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            f1 = new FileReader("D:\\JAVA\\Personal Project\\stop_word.txt");
            f2 = new FileReader("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            b1 = new BufferedReader(f1);
            b2 = new BufferedReader(f2);
            List<String> list1 = new ArrayList<>();
            Map<String, Integer> m1 = new HashMap<String, Integer>();
            String temp = "";
            while ((temp = b1.readLine()) != null) {   //读入的是停词表当中的数据
                String s1 = temp.trim();
                list1.add(s1);
            }
            while ((temp = b2.readLine()) != null) {
                StringBuilder sb = new StringBuilder();
                String s2 = temp.trim();
                for (int i = 0; i < s2.length(); i++) {
                    if ((s2.charAt(i) >= 97 && s2.charAt(i) < 123) || (s2.charAt(i) >= 65 && s2.charAt(i) < 91) || (s2.charAt(i) == ' ')) {
                        sb.append(s2.charAt(i));
                    }
                }
                s2 = sb.toString();
                String[] s1 = s2.split(" ");

                label:
                for (String i : s1) {
                    if(list1.contains(i)) {
                        continue;
                    } else {
                        if (m1.get(i) == null) {
                            m1.put(i, 1);
                        } else {
                            m1.put(i, m1.get(i) + 1);
                        }
                    }
                    /*for (String j : list1) {
                        if (j.equals(i)) {
                            continue label;
                        } else {
                            if (m1.get(i) == null) {
                                m1.put(i, 1);
                            } else {
                                m1.put(i, m1.get(i) + 1);
                            }
                        }
                    }*/
                }
            }
            fw = new FileWriter("D:\\JAVA\\Personal Project\\stopCharacter.txt");
            bw = new BufferedWriter(fw);
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<String, Integer>> entries = m1.entrySet();
            for (Map.Entry<String, Integer> entry : entries) {
                bw.write(entry.getKey() + "   出现了  " + entry.getValue() + "次");
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fw != null) {
                try {
                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (f1 != null) {
                try {
                    f1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (f2 != null) {
                try {
                    f2.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (b1 != null) {
                try {
                    b1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (b2 != null) {
                try {
                    b2.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 记录字符的个数
     */
    public static void count_Char() {
        FileReader fr = null;
        BufferedWriter bw = null;
        double sum = 0;
        try {
            Map<Character, Integer> m1 = new HashMap<>();
            fr = new FileReader("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            int c;
            while ((c = fr.read()) != -1) {
                char ch = (char) c;

                if ((ch >= 97 && ch <= 122) || (ch >= 65 && ch <= 90)) {
                    if (m1.get(ch) == null) {
                        m1.put(ch, 1);
                    } else {
                        m1.put(ch, m1.get(ch) + 1);
                    }
                }
            }
            bw = new BufferedWriter(new FileWriter("D:\\JAVA\\Personal Project\\wordCount.txt"));
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<Character, Integer>> entrySet = m1.entrySet();
            for (Map.Entry<Character, Integer> entry : entrySet) {   //sum要先求完
                sum += entry.getValue();
            }
            for (Map.Entry<Character, Integer> entry : entrySet) {
                DecimalFormat df = new DecimalFormat("0.00");
                bw.write(entry.getKey() + "=" + entry.getValue() + "频率为：" + df.format(entry.getValue() * 100 / sum) + "%");
                bw.newLine();
            }

        } catch (IOException E) {
            E.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * 传入地址记录字符的个数
     */
    public static void count_Char(String add) {
        FileReader fr = null;
        BufferedWriter bw = null;
        double sum = 0;
        try {
            Map<Character, Integer> m1 = new HashMap<>();
            fr = new FileReader(add.toString());
            int c;
            while ((c = fr.read()) != -1) {
                char ch = (char) c;

                if ((ch >= 97 && ch <= 122) || (ch >= 65 && ch <= 90)) {
                    if (m1.get(ch) == null) {
                        m1.put(ch, 1);
                    } else {
                        m1.put(ch, m1.get(ch) + 1);
                    }
                }
            }
            bw = new BufferedWriter(new FileWriter("D:\\JAVA\\workSpace1\\wordCount.txt"));
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<Character, Integer>> entrySet = m1.entrySet();
            for (Map.Entry<Character, Integer> entry : entrySet) {   //sum要先求完
                sum += entry.getValue();
            }
            for (Map.Entry<Character, Integer> entry : entrySet) {
                DecimalFormat df = new DecimalFormat("0.00");
                bw.write(entry.getKey() + "=" + entry.getValue() + "频率为：" + df.format(entry.getValue() * 100 / sum) + "%");
                bw.newLine();
            }

        } catch (IOException E) {
            E.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 记录行数的个数
     */
    public static void count_line() {
        int count = 0;
        long count1 = 0;
        InputStreamReader fr = null;
        BufferedReader b1 = null;
        try {
            File f1 = new File("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            fr = new InputStreamReader(new FileInputStream(f1));
            b1 = new BufferedReader(fr);
            //count1 = b1.lines().count(); 直接统计行数
            while (b1.readLine() != null) {
                count++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (b1 != null) {
                try {
                    b1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("该文档中共计有" + count + "行");
    }

    /**
     * 记录单词的个数
     */
    public static void count_character() {
        FileReader fr = null;
        BufferedWriter bw = null;
        FileWriter wr = null;
        BufferedReader br = null;
        try {
            Map<String, Integer> m1 = new HashMap<String, Integer>();
            fr = new FileReader("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            br = new BufferedReader((fr));
            String temp = "";
            while ((temp = br.readLine()) != null) {
                String str = temp;
                StringBuilder sb = new StringBuilder();
                String str1 = str.trim();//去除头尾空格
                for (int i = 0; i < str1.length(); i++) {
                    if ((str1.charAt(i) >= 97 && str1.charAt(i) < 123) || (str1.charAt(i) >= 65 && str1.charAt(i) < 91) ||
                            str1.charAt(i) == ' ') {
                        sb.append(str1.charAt(i));
                    }
                }
                str = sb.toString();
                String[] s1 = str.split(" ");
                for (String i : s1) {
                    if (m1.get(i) == null) {
                        m1.put(i, 1);
                    } else {
                        m1.put(i, m1.get(i) + 1);
                    }
                }
            }
            wr = new FileWriter("D:\\JAVA\\Personal Project\\Character.txt");
            bw = new BufferedWriter(wr);
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<String, Integer>> entries = m1.entrySet();
            for (Map.Entry<String, Integer> entry : entries) {
                if (entry.getKey() == "") {
                    continue;
                }
                bw.write(entry.getKey() + "   出现了  " + entry.getValue() + "次");
                bw.newLine();
            }
        } catch (IOException E) {
            E.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (wr != null) {
                try {
                    wr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /*
    显示频率最高的前n个单词
     */

    /**
     * 记录单词的个数
     */
    public static void count_character(int n) {
        int count = 0;
        FileReader fr = null;
        BufferedWriter bw = null;
        FileWriter wr = null;
        BufferedReader br = null;
        //ArrayList<String> ar=new ArrayList<>(10);   这里用arraylist 却不行
        try {
            Map<String, Integer> m1 = new HashMap<String, Integer>();
            fr = new FileReader("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            br = new BufferedReader((fr));
            String temp = "";
            while ((temp = br.readLine()) != null) {
                String str = temp;
                StringBuilder sb = new StringBuilder();
                String str1 = str.trim();//去除头尾空格
                for (int i = 0; i < str1.length(); i++) {
                    if ((str1.charAt(i) >= 97 && str1.charAt(i) < 123) || (str1.charAt(i) >= 65 && str1.charAt(i) < 91) ||
                            str1.charAt(i) == ' ') {
                        sb.append(str1.charAt(i));
                    }
                }
                str = sb.toString();
                String[] s1 = str.split(" ");
                for (String i : s1) {
                    if (m1.get(i) == null) {
                        m1.put(i, 1);
                    } else {
                        m1.put(i, m1.get(i) + 1);
                    }
                }
            }
            wr = new FileWriter("D:\\JAVA\\Personal Project\\Character_theFirst.txt");
            bw = new BufferedWriter(wr);
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<String, Integer>> entries = m1.entrySet();
            for (Map.Entry<String, Integer> entry : entries) {
                if (count++ == n) {
                    break;
                }
                if (entry.getKey() == " ") {
                    continue;
                }
                bw.write(entry.getKey() + "   出现了  " + entry.getValue() + "次");
                bw.newLine();

            }
        } catch (IOException E) {
            E.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (wr != null) {
                try {
                    wr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /*
        将所需求单词，转化成为动词原形进行记录

     */
    public static void count_VerCharacter() {
        FileReader fr = null;
        BufferedWriter bw = null;
        FileWriter wr = null;
        BufferedReader br = null;
        FileReader fr1 = null;
        BufferedReader br1 = null;
        try {
            Map<String, Integer> m1 = new HashMap<String, Integer>();
            fr = new FileReader("D:\\JAVA\\Personal Project\\HarryPotter.txt");
            br = new BufferedReader((fr));
            fr1 = new FileReader("D:\\JAVA\\Personal Project\\Verb.txt");
            br1 = new BufferedReader((fr1));
            String temp = "";
            String temp1 = "";
            String[] s2 = new String[5];
            while ((temp1 = br1.readLine()) != null) {
                String str1 = temp1.trim();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < str1.length(); i++) {
                    if ((str1.charAt(i) >= 97 && str1.charAt(i) < 123) || (str1.charAt(i) >= 65 && str1.charAt(i) < 91) ||
                            str1.charAt(i) == ' ') {
                        sb.append(str1.charAt(i));
                    }
                }
                temp1 = sb.toString();
                s2 = temp1.split(" ");
            }
            while ((temp = br.readLine()) != null) {
                String str = temp;
                StringBuilder sb = new StringBuilder();
                String str1 = str.trim();//去除头尾空格
                for (int i = 0; i < str1.length(); i++) {
                    if ((str1.charAt(i) >= 97 && str1.charAt(i) < 123) || (str1.charAt(i) >= 65 && str1.charAt(i) < 91) ||
                            str1.charAt(i) == ' ') {
                        sb.append(str1.charAt(i));
                    }
                }
                str = sb.toString();
                String[] s1 = str.split(" ");
                label:
                for (String i : s1) {    //这里的逻辑上是遍历新容器和规范容器
                    for (int j = 0; j < s2.length; j++) {     //一但有了相同值就把开头单词给写入，并且直接回到大循环体
                        if (s2[j].equals(i)) {
                            if (m1.get(s2[0]) == null) {
                                m1.put(s2[0], 1);
                            } else {
                                m1.put(s2[0], m1.get(s2[0]) + 1);
                            }
                            continue label;
                        }
                    }
                    if (m1.get(i) == null) {
                        m1.put(i, 1);
                    } else {
                        m1.put(i, m1.get(i) + 1);
                    }
                }
            }
            wr = new FileWriter("D:\\JAVA\\Personal Project\\Character_Verb.txt");
            bw = new BufferedWriter(wr);
            m1 = sortByValueDescending(m1);
            Set<Map.Entry<String, Integer>> entries = m1.entrySet();
            for (Map.Entry<String, Integer> entry : entries) {

                if (entry.getKey() == " ") {
                    continue;
                }
                bw.write(entry.getKey() + "   出现了  " + entry.getValue() + "次");
                bw.newLine();

            }
        } catch (IOException E) {
            E.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (wr != null) {
                try {
                    wr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br1 != null) {
                try {
                    br1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fr1 != null) {
                try {
                    fr1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    //获取文件目录
    public static List<String> getFileList(File file) {
        List<String> result = new ArrayList<String>();
        if (!file.isDirectory()) {
            System.out.println(file.getAbsolutePath());
            result.add(file.getAbsolutePath());
        } else {
            File[] directoryList = file.listFiles(new FileFilter() {
                public boolean accept(File file) {
                    if (file.isFile() && file.getName().indexOf("txt") > -1) {
                        return true;
                    } else {
                        return false;
                    }
                }
            });
            for (int i = 0; i < directoryList.length; i++) {
                result.add(directoryList[i].getPath());
            }
        }
        return result;
    }

    //遍历文件目录中的内容
    public static void dict(String n) {
        File f=null;
        BufferedReader br=null;
        try {
            String FILE_IN = n;
            f = new File(FILE_IN);
            List<String> list = new ArrayList<String>();
            list = getFileList(f);
            System.out.println("共计文件个数为："+ list.size());
            for (String l : list) {
                br = new BufferedReader(new FileReader(new File(l)));
                String[] sp = l.split("\\\\");
                System.out.println("当前正在读取的文件是："+sp[sp.length-1]);
                String s1="";
                while((s1=br.readLine())!=null) {
                    System.out.println(s1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(br!=null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static void main(String[] args) {
        stop_word();
       /* String order = args[0];
        switch (order) {
            case "count_char":
                count_Char();
                break;
            case "countCharacter":
                count_character();
                break;
            case "stopFile":
                stop_word();
                break;
            case "countLine":
                count_line();
                break;
            case "count_n":
                count_character(Integer.parseInt(args[1]));
                break;
            case "count_add":
                count_Char(args[1]);
                break;
            case "count_verb":
                count_VerCharacter();
                break;
            case "dict":
                dict(args[1]);
                break;
        }*/
    }
}
