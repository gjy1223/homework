/**
 * @author chenlei
 * @create 2021-04-11-20:37
 */
public class asd {
    public static int nthUglyNumber(int n) {
        int count=1;
        int flag=0;
        for(int i=2;i<=1690;i++) {
            flag=i;
            while(i%2==0) {
                i/=2;
            }
            while(i%3==0) {
                i/=3;
            }
            while(i%5==0) {
                i/=5;
            }
            if(i==1) {
                count++;
                if(count==n) {
                    break;
                }
            }
        }
        return flag;
    }
    public static void main(String[] args) {
        nthUglyNumber(10);
    }
}
