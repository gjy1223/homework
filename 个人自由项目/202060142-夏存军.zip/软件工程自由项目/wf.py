from collections import Counter
import operator
# TODO 输出某个英文文本文件中 26 字母出现的频率，由高到低排列，并显示字母出现的百分比，精确到小数点后面两位。
total = 0
wf = open("wf", "r")
sw = open("stop_word", "r")
sw_str = sw.read()
wf_str = wf.read()
letter_dict = {}
wf_list = wf_str.split()


def letter_stat():
    total = 0
    for i in range(65, 91):
        letter_dict[chr(i)] = wf_str.count(chr(i))
    for i in range(97, 123):
        letter_dict[chr(i)] = wf_str.count(chr(i))
    # print(sorted(letter_dict.items(), key=operator.itemgetter(1)))
    for i in letter_dict:
        total = total + letter_dict[i]
    # print(total)
    for i in letter_dict:
        a = "%.2f%%" % ((letter_dict[i]/total)*100)
        letter_dict[i] = a
    # 先对value排序，再对key排序。
    print(sorted(letter_dict.items(), key=lambda x: (x[1], x[0])))


# TODO 输出单个文件中的前 N 个最常出现的英语单词，并 支持 stop words。
def word_stat():
    n = int(input("请输入要统计的数量"))
    wf_obj = Counter(wf_list)
    print(wf_obj.most_common(n))


# TODO 支持stop_word
def word_stop():
    count = int(input("请输入要统计的数量"))
    sw_list = sw_str.split()
    for i in wf_list:
        if i in sw_list:
            wf_list.remove(i)
    sw_obj = Counter(wf_list)
    print(sw_obj.most_common(count))


letter_stat()
word_stat()
word_stop()

