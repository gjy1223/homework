import argparse,os

def letterRate(letterPath):
    if not os.path.exists(letterPath):
        return
    with open(letterPath, 'r') as file:
        txt=file.read().lower();
    letterSum=0
    letterNum={}
    for letter in txt:
        if (letter.isalpha()):
            letterSum+=1
            letterNum[letter]=letterNum.get(letter,0)+1
    letterNum=sorted(letterNum.items(),key=lambda a:a[0])
    letterRate={}
    for (letter,num) in letterNum:
        letterRate[letter]=round(num/letterSum,2)
    print(sorted(sorted(letterRate.items(),key=lambda a:a[0]),key=lambda b:b[1],reverse=True))

def wordRate(wordPath,stopPath,top,verbForm):
    if os.path.isdir(wordPath):
        fileList = os.listdir(wordPath)
        for file in fileList:
            wordRate(os.path.join(wordPath, file),stopPath,top,verbForm)
    else:
        if not os.path.exists(wordPath):
            return
        with open(stopPath, 'r') as file:
            stop = file.read().lower()
        with open(wordPath, 'r') as file:
            txt = file.read().lower()
        words = txt.split()
        wordNum = {}
        for word in words:
            if word[0].isalpha() and not word in stop:
                if (word in verbForm):
                    word=verbForm[word]
                wordNum[word] = wordNum.get(word, 0) + 1
        wordSorted=sorted(sorted(wordNum.items(), key=lambda a: a[0]), key=lambda b: b[1], reverse=True)
        print(wordSorted)
        top=len(wordSorted) if top==None or top>len(wordSorted) else top
        print("The top %d words of %s are:" %(top,wordPath))
        for i in range(top):
            print(wordSorted[i][0])

def getVerbForm(verbPath):
    if not os.path.exists(verbPath):
        return
    verbForm={}
    with open(verbPath,'r') as file:
        line=file.readline().lower()
        while line:
            verbs=line.split()
            for i in range(1,len(verbs)):
                verbForm[verbs[i]]=verbs[0]
            line=file.readline().lower()
    return verbForm


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--letter", type=str, default="./test.txt",help="path of txt,letter")
    parser.add_argument("--word", type=str, default="./test", help="path of txt,word")
    parser.add_argument("--stop",type=str, default="./stopwords.txt",help="path of stopword")
    parser.add_argument("--top",type=int, help="top word")
    parser.add_argument("--verb", type=str, default="./verb.txt", help="path of verb")
    config=parser.parse_args()
    verbForm=getVerbForm(config.verb)
    letterRate(config.letter)
    wordRate(config.word,config.stop,config.top,verbForm)