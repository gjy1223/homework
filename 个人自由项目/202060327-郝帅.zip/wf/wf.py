#导入正则表达式re模块
from collections import Counter
import re
import math

#统计字母出现次数和频率
def Number_Of_Letters():                       #定义统计函数
    fp = open("wf.txt").readlines()
    Total_Number_Of_Letters = 0
    Sum = 0
    for line in fp:
        RemoveSymbol = '[0-9’!"$&\'''()\*+,-./:;?、…《》？“”‘’！\\^_`]+'  # 定义标点符号集
        line = line.strip('\n')                                         # 去除每行中的换行符
        line = str(line)                                                # str函数，转换为字符串形式
        line = line.replace(' ', '')                                    # 去除每行中的空格
        line = line.lower()                                             # 把所有字母都转换成小写字母
        line = re.sub(RemoveSymbol, '', line)                           # 去除标点符号
        Total_Number_Of_Letters = len(line) + Total_Number_Of_Letters   # len()的返回值为int类型。
        Sum = str(Sum) + line
    print("字母总数：" + str(Total_Number_Of_Letters))

    Dict = { 'a':0,'b':0,'c':0,'d':0,'e':0,'f':0,'g':0,'h':0, 'i':0,'j':0, 'k':0,'l':0, 'm':0,
             'n':0,'o':0,'p':0,'q':0,'r':0,'s':0,'t':0, 'u':0,'v':0,'w':0,'x':0, 'y':0,'z':0}       #创建字典 （键：值）
    for EveryLetter in Sum:
        if EveryLetter.isalpha():                                                                   #遍历文本，统计每个字母出现次数，存到字母字典中,.isalpha()判断是否含有字母，否则返回0
            OccurNumber = Sum.count(EveryLetter)                                                    #.count(）统计出现次数
            Dict[EveryLetter] = OccurNumber
        Letters_Descending_Order = sorted(Dict.items(),key=lambda a:a[1],reverse=True)              #reverse=True降序排列，.items()以列表返回可遍历的(键, 值) 元组数组  a:a[1] 列表的第二维进行排序
    for key,value in Letters_Descending_Order:
        print(f"字母:{key}")                                                                         #加f可以引用后面的参数
        print(f"次数:{value}")
        print( '频率:' +  format(float(value/Total_Number_Of_Letters*100),".2f" ) + "%")

#查看出现次数最多的N个单词

def Number_Of_Words():
    N = int(input("请输入你想查看的出现次数排名前n的单词："))
    WordList = []
    WordDict = {}
    fp = open("wf.txt",'r')                                                      #以只读形式打开txt
    for line in fp.readlines():                                                  #把txt中每行文本作为一个字母串存入一个列表中，返回该列表
        for Word in line.strip().split(" "):                                     #以空格来分割字符串，返回切割的列表（判定单词）
            WordList.append(re.sub(r"[.!,?+—*/']","",Word.lower()))              #将每行所有字母全部小写，并且将每行中的符号去除，添加到单词列表中
            Total_Number_Of_Words = len(WordList)                                #单词列表的长度就是单词总数
            WordSets = list(set(WordList))                                       #set集合里的元素不能重读，用于去除WordList中重复的单词
            WordDict = {Word:WordList.count(Word) for Word in WordSets if Word}  #将每个单词的词名和出现次数写入字典的键和值
    print("单词总数："+str(Total_Number_Of_Words))
    Word_Result=sorted(WordDict.items(),key=lambda a:a[1],reverse=True)          #对键值进行排序
    for Key,Value in Word_Result:
        print(f"\n单词:{Key}")
        print(f"次数:{Value}")
    print('===========================')
    Word_Result_List=[]
    for Key,Value in Word_Result:                                                #将字典中的键和值加入到列表中
        Word_Result_List.append((Key,Value))

    print("\n出现次数前"+str(N)+"的单词：")
    for the_number_of_Words,Occurrence_Number in Word_Result_List[:N]:           #打印出现次数前n的单词
        print(the_number_of_Words)

#查看除了“of、is、the”之外的出现次数最多的n个单词

def Number_Of_Words_Without_some_words():
    N = int(input("请输入你想查看的除了of、is、the之外的出现次数排名前n的单词："))
    fp = open("wf.txt").readlines()
    # 去除of、is、the
    WordList = []
    WordDict = {}
    for line in fp:
        for Word in line.strip().split(" "):                                      #以空格为分割来界定单词
            if Word != "of" and Word != "is" and Word != "the":                   #若单词不是of、is、the，则加入到单词列表
                WordList.append(re.sub(r"[.|!|,]", "", Word.lower()))             #将字母转换为小写，去除符号
            elif Word == "of" or Word == "is" or Word == "the":  pass             #若单词是of、is、the，则跳过
            Total_Number_Of_Words = len(WordList)                                 #单词总数（除of、is、the）
            WordSets = list(set(WordList))                                        #去除WordList中重复的单词
            WordDict = {Word: WordList.count(Word) for Word in WordSets if Word}  #将每个单词的词名和出现次数写入字典的键和值
    print("除了of、is、the之外的单词总次数：" + str(Total_Number_Of_Words))
    WordResult = sorted(WordDict.items(), key=lambda item: (-item[1], item[0]))
    for Key, Value in WordResult:
        print(f"\n单词:{Key}")
        print(f"次数:{Value}")
    print('===========================')
    WordResultList = []
    for Key, Value in WordResult:
        WordResultList.append((Key, Value))

    print("\n除了of、is、the之外的出现次数前"+str(N)+"的单词：")
    for TheFirstNWords, OccurrenceNumber in WordResultList[:N]:
        print(TheFirstNWords)


Number_Of_Letters()
Number_Of_Words()
Number_Of_Words_Without_some_words()

