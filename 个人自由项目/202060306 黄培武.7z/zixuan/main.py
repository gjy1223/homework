import argparse
from count import *


parser = argparse.ArgumentParser()
chooseOne = parser.add_mutually_exclusive_group() #定义一个互斥组，chooseOne内只能同时使用一个选项
chooseOne.add_argument('-c','--letter',action = 'store_true')
chooseOne.add_argument('-f','--word',action = 'store_true')
chooseOne.add_argument('-p','--phrase',type = int)
parser.add_argument('-d','--directoryF', help="folder",action = "store_true")
parser.add_argument('-s','--subfolderF', help="sub folers",action = "store_true")
parser.add_argument('-x','--stopFile', help="stop file",default = None)
parser.add_argument('-v','--verbFile', help="Verb file to normalize the veb tenses",default = None)
parser.add_argument('--num', type = int , default ="10",help="The file/directory to be operated with")
parser.add_argument('path',help="The file/directory to be operated with")


if __name__ == '__main__':
    args = parser.parse_args()
    if(args.letter):
        if (args.directoryF):
            OperateDirectory(CountLetters,args.path,args.num,args.stopFile,args.subfolderF)
        else:
            CountLetters(args.path,args.num)

    if(args.word):
        if(args.directoryF):
            OperateDirectory(CountWords,args.path,args.num,args.stopFile,args.verbFile,args.subfolderF)
        else:
            CountWords(args.path,args.num,args.stopFile,args.verbFile)

    if(args.phrase):
        if (args.directoryF):
            OperateDirectory(countPhrase, args.path, args.num, args.stopFile, args.verbFile,args.subfolderF,args.phrase)
        else:
            countPhrase(args.path,args.num,args.stopFile,args.verbFile,args.phrase)

