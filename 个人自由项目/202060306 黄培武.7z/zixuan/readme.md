##输出字母： 
### python main.py -c gone_with_the_wind.txt --num 10
![img.png](img1.png)

##输出单词：
### python main.py -f gone_with_the_wind.txt --num 10

![img.png](img2.png)
### 指定目录：python main.py -f -d testfolder --num 10
![img.png](img3.png)
### 指定目录及子目录：python main.py -f -d -s testfolder --num 5
![img.png](img4.png)

### 指定stop words： （以去掉the为例）
#### python main.py -f gone_with_the_wind.txt --num 10 -x stopfile.txt
![img.png](img5.png)

### 动词形态统一： 
#### 原：python main.py -f verbtest.txt --num 10         
![img.png](img6.png)        

#### 统一后：python main.py -f verbtest.txt --num 10  -v verbs.txt
![img.png](img7.png)

## 输出短语
#### python main.py -p 2 gone_with_the_wind.txt --num=10
![img.png](img8.png)

#### python main.py -p 3 gone_with_the_wind.txt --num=10
![img.png](img9.png)

#### 动词形态统一：python main.py -p 3 gone_with_the_wind.txt -v verbs.txt
![img.png](img10.png)