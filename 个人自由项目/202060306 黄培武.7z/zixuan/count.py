from utils import *
import re
from collections import Counter
letters = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

def CountLetters(path,num,stopfile=False):
    print(path)
    dicLetter = {} #定义一个空字典，存储结果
    allNum = 0
    with open(path) as f:
        txt = f.read().lower()
    for letter in letters:
        dicLetter[letter] = txt.count(letter)  # 计算每个字母的个数，存入字典dicNum中  不区分大小写  重叠的也都计算
        allNum += dicLetter[letter]
    # 对key进行排序，目的是，当出现概率相同的时候，根据字母顺序排序，返回的是list
    dicLetter = sorted(dicLetter.items(), key=lambda k: k[0])
    dicLetter = sorted(dicLetter,key = lambda k: k[1], reverse=True)  # 对值进行排序，降序
    DisplayLetter(dicLetter[0:num],allNum)




def CountWords(path,num,stopfile,verbfile):
    print("\"%s\"   "%(path))

    if(stopfile != None):
        stopflag = True
    else:
        stopflag = False

    if(verbfile != None):
        verbflag = True
    else:
        verbflag = False

    if(stopflag ==True):
        with open(stopfile) as f:
            stoplist = f.readlines()

    with open(path) as f:
        txt = f.read().lower() #读取txt文件的内容，并将大写字母转换为小写
    pattern = r"[a-z][a-z0-9]*"  #正则表达式，匹配全是字母、或开头字母结尾数组的字符串
    wordList = re.findall(pattern, txt)
    allNum = len(wordList)
    tempc = Counter(wordList) #对wordList中的字母进行计数

    if (stopflag == True):
        for word in stoplist:
            word = word.replace('\n','')
            try:
                del tempc[word]
            except:
                pass

    dicWord = dict(tempc.most_common(num))
    if (verbflag == True):
        totalNum = 0
        verbDic = {}
        verbDicNum = {}
        with open(verbfile) as f:
            for line in f.readlines():
                key,value = line.split(' -> ')
                verbDic[key] = value.replace('\n','').split(',')
                verbDicNum[key] = tempc[key]
                for word in verbDic[key]:
                    verbDicNum[key] += tempc[word]
                totalNum += verbDicNum[key]
        verbDicNum = sorted(verbDicNum.items(), key=lambda k: k[0])
        verbDicNum = sorted(verbDicNum, key=lambda k: k[1], reverse=True)

    dicWord = sorted(dicWord.items(), key=lambda k: k[0])
    dicWord = sorted(dicWord,key = lambda k: k[1], reverse=True)  # 对值进行排序，降序
    if(verbflag == True):
        DisplayWord(verbDicNum[:num], allNum)
    else:
        DisplayWord(dicWord, allNum)


def countPhrase(path,num,stopfile,verbfile,phraseNum):
    print("\"%s\"   "%(path))
    allNum=0
    if(stopfile != None):
        stopflag = True
    else:
        stopflag = False

    if(verbfile != None):
        verbflag = True
    else:
        verbflag = False

    with open(path) as f:
        txt = f.read().lower()
    txt = re.sub(r'\s+', ' ', txt)  # 将多个空白字符，包括空格、制表符、换页符等等, 比如[ \f\n\r\t\v]，替换为一个空格
    pword = r'(([a-z]+ )+[a-z]+)'  # [a-z]+ 匹配一个单词   ([a-z]+ )一个子正则表达式     ([a-z]+ ) +   一个或以上单词     [a-z] +  最后再来一个单词
    pattern = re.compile(pword)  #编译正则表达式，生成一个pattern对象
    sentence = pattern.findall(txt) #返回一个列表，存的是每个短语
    txt = ','.join([sentence[m][0] for m in range(len(sentence))]) #用逗号，将所有短语连接起来
    if (stopflag == True):
        with open(stopfile) as f:
            stoplist = f.readlines()
            stopNum = len(stoplist)
    pattern = "[a-z]+[0-9]*"  #一个单词
    for i in range(phraseNum - 1):
        pattern += "[\s|,][a-z]+[0-9]*"   #\s 匹配任何空白字符   | 两个选一个
    wordList = []
    for i in range(phraseNum):
        if( i == 0 ):
            tempList = re.findall(pattern, txt) #生成一个list，存的是phraseNum数量的短语，中间可以是空格或者，
        else:
            wordpattern = "[a-z]+[0-9]*"

            # 去掉第一个单词，这样整体就向后移动一个
            # we can play basketball     -->we can    play basketball
            # can play basketball        -->can play  basketball *
            # 这样就可以把所有短语都放到wordlist里面，不会漏掉
            txt1 = re.sub(wordpattern, '', txt, 1).strip()
            tempList = re.findall(pattern, txt1)
        wordList += tempList
    tempc = Counter(wordList)
    if (stopflag == True):
        for word in stoplist:
            word = word.replace('\n', '')
            try:
                del tempc[word]
            except:
                pass
    dicPhrase = {}

    if(verbflag == True):
        verbDic = {}
        with open(verbfile) as f:
            for line in f.readlines():
                key, value = line.split(' -> ')
                for tverb in value.replace('\n', '').split(','):
                    verbDic[tverb] = key
                verbDic[key] = key
        for phrase in tempc.keys():
            if (',' not in phrase):
                allNum += 1
                splitlist = phrase.split(' ')
                normPhrase=''
                for i in range( len(splitlist)):
                    if(i!=0):
                        normPhrase +=' '
                    if( splitlist[i] in verbDic.keys()):
                        normPhrase += verbDic[splitlist[i]]
                        changeFlag = True
                    else:
                        normPhrase += splitlist[i]
                        changeFlag = False

                if (changeFlag):
                    if (normPhrase in dicPhrase.keys()):
                        dicPhrase[normPhrase] += tempc[phrase]
                    else:
                        dicPhrase[normPhrase] = tempc[phrase]
    else:
        phrases = tempc.keys()
        for phrase in phrases:
            if (',' not in phrase): #去掉包括逗号的
                dicPhrase[phrase] = tempc[phrase]
                allNum += tempc[phrase]
    dicPhrase = sorted(dicPhrase.items(), key=lambda k: k[0])
    dicPhrase = sorted(dicPhrase, key=lambda k: k[1], reverse=True)
    DisplayWord(dicPhrase[:num], allNum)