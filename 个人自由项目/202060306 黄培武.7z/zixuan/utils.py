import os
def DisplayLetter(dict,num):
    for word, fre in dict:
        fre = fre/num*100
        print("%s:%.2f"%(word,fre),'%')



def DisplayWord(dict,num):
    for word, fre in dict:
        fre = fre/num*100
        if fre==0:
            break
        print("%s:%.2f"%(word,fre),'%')

def OperateDirectory(Func,Dir_name,num,stopfile,verbfile,subfolderF,*arges):
    if(subfolderF):
        for path, _, filelist in os.walk(Dir_name):
            for file in filelist:

                if (arges):
                    Func(os.path.join(path, file), num, stopfile,verbfile,arges[0])
                else:
                    Func(os.path.join(path,file), num,stopfile,verbfile)


    else:
        for file in os.listdir(Dir_name):

            if(os.path.isdir(os.path.join(Dir_name,file))):
                pass
            else:
                if (arges):
                    Func(os.path.join(Dir_name, file), num, stopfile, verbfile,arges[0])
                else:
                    Func(os.path.join(Dir_name,file), num,stopfile,verbfile)

