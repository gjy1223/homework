def max_sum(n,the_list):
    sum=[]#存放结果
    for i in range(n):#i是一共有几个数参与运算
        sum.append(the_list[i])
        for num in the_list[:-int(i)]:#遍历参与求和的第一个数字，重复length-i次
            index = the_list.index(num)#第一个数字的index
            add_ans=0
            print(the_list[:-int(i)])
            for i_current in range(i+1):#共有i+1个数字参与运算
                add_ans+=the_list[int(index+i_current)]
            sum.append(add_ans)

    print(sum)
    print(max(sum))

if __name__=='__main__':
    a=5
    b=[1,2,3,-2,-5]
    max_sum(a,b)
