import re
import operator
def text_handling(filename,n,filtering_words,diff_tenses):
    # 读取含有不同时态动词的文件
    if diff_tenses==True:#读取含有不同时态动词的文件
        with open('verb_file.txt', 'r') as f:
            file_read = f.read().split('\n')#行分割
        dict_verb = {}#用字典表示文件内容
        for phrase in file_read:
            words = re.split(r'[\s]', phrase)  # 空白符分隔文本
            if words[0] not in dict_verb:
                dict_verb[words[0]] = words #dict_verb是动词矩阵

    # 读取含其单词等待统计的文本文件
    file_read=[]#存放文本
    with open(filename,'r') as f:#filename指的是文件夹下等待遍历的txt文件
        file_read=f.read()
    if diff_tenses==True:# 就是把动词的各种变形都归为它的原型来统计
        file_read=re.split(r'[\s,.;?]', file_read)  # 用逗号句号问号空白符分隔文本
        for num, word in enumerate(file_read):
            for keys, values in dict_verb.items():
                if word in values:
                    file_read[num] = keys
        file_read=list(filter(None, file_read))
        print('已读取统一不同动词时态后的文本文件：\n',file_read)#生成统一时态的list
    else:
        print('已读取原文本文件：\n',file_read)#生成未统一时态的list



    words=''.join(e for e in file_read if e.isalnum())#过滤空白符；.isalnum()判断是否为字母或者数字，join语法用于组合字母和数字
    ##统计字母频率
    seq=('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','i','s','t','u','v','w','x','y','z')
    dict0=dict.fromkeys(seq,0)#组成一个value都为0的字典
    length0=len(words)
    for word in words:
        if word in dict0.keys():
            dict0[word]+=1/length0
        else:
            continue
    dict0=sorted(dict0.items(), key=operator.itemgetter(1),reverse=True)
    print('\n文本文件{0}中的各个字母出现频率为：{1}\n'.format(filename,dict0))

    ##统计单词频率
    dict1={}
    if diff_tenses==True:
        split=file_read
    else:
        split = re.split(r'[\s,.;?]', file_read)  # 用逗号句号问号空白符分隔文本
    file_split=list(filter(lambda x : x if x not in filtering_words else "",split))#过滤掉给定单词
    length1=len(file_split)
    for word in file_split:
        if word !='':#经过查看result_list中还有''
            if word.lower() not in dict1:
                dict1[word.lower()]=1/length1
            else:
                dict1[word.lower()]+=1/length1
    dict1=sorted(dict1.items(), key=operator.itemgetter(1),reverse=True)#按照value值降序dict的keys
    if n!=0:#支持 -n 参数，输出出现次数最多的前 n 个单词，当没有指明数量的时候，我们默认列出所有单词的频率。
        print('文本文件{0}中频率排名前{1}个英语单词出现频率为：{2}\n'.format(filename,n,list(dict1)[0:n]))
    else:
        print('文本文件{0}中的各个英语单词出现频率为：{1}\n'.format(filename,list(dict1)))

    ##统计短语
    with open(filename, 'r') as f:
        file_read = f.read()
        file_split2 = re.split(r'[,.;?]', file_read)
        while '' in file_split2:
            file_split2.remove('')
    new_string=''
    #print('old file_split2', file_split2)
    if diff_tenses == True:#替换短语
        for index1, string in enumerate(file_split2):
            for index2, every_str in enumerate(string.split(' ')):
                for keys, values in dict_verb.items():#遍历动词时态字典
                    if every_str in values:
                        a=[]
                        for index,word in enumerate(string.split(' ')):
                            if every_str == word:
                                word=keys
                            a.append(word)
                            new_string=' '.join(a)
                        file_split2[index1] = new_string
    #print('file_split2',file_split2)
    list_phrase=[]
    dict_phrase={}
    num_phrase=int(input('你希望得到含有几个单词的短语:'))
    for string in file_split2:#遍历多个strings
        for i in range(len(string.split(' '))-num_phrase+1):
            for j in range(num_phrase):
                if string.split(' ')[i+j]==' ':#防止出现把空字符串算作一个字符的情况
                    break
                list_phrase.append(string.split(' ')[i+j])
                phrase=' '.join(list_phrase)
            list_phrase = []
            if phrase not in dict_phrase:
                dict_phrase[phrase]=1
            else:
                dict_phrase[phrase]+=1
    dict2 = sorted(dict_phrase.keys(), key=operator.itemgetter(1), reverse=True)
    print('文本文件{0}含有{1}个单词的词组有{2}'.format(filename,num_phrase,dict2))#根据词组的频率降序输出词组

import sys
import os
path=sys.argv[1]#输入参数：文件夹路径'
filtering_file=sys.argv[2]#输入参数：存放给定过滤单词的文本文件
with open(os.path.join(path,filtering_file),'r') as f:
    filtering_words=f.read().split(',')#filtering_words中是需要跳过的词汇

names=[]
for file in os.listdir(path):#读取文件夹下的文件目录
    file_path=os.path.join(path,file)
    if os.path.splitext(file_path)[1]=='.txt':
        names.append(file_path)
n=input('你希望输出频率排名前几的单词:')
verb_wether=input('统一动词形态：y/n?')
if verb_wether=='y':
    diff_tenses = True
else:
    diff_tenses=False
for filename in names[1:]:#依次读取文件
    if n=='':#支持 -n 参数，输出出现次数最多的前 n 个单词，当没有指明数量的时候，我们默认列出所有单词的频率。
        text_handling(filename,int(0),filtering_words,diff_tenses)
    else:
        text_handling(filename, int(n),filtering_words,diff_tenses)