#pragma once
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

typedef pair<string, int> PAIR;

struct  cmpWordFrequency
{
	bool operator()(const pair<string, int>& a, const pair<string, int>& b)
	{
		if (a.second == b.second)
			return a.first < b.first;
		else
			return a.second > b.second;
	}
};


class WordFrequency
{
public:
	WordFrequency(vector<string> filePath);
	void countWordFrequency(vector<string> filePath);
	void sortWordFrequency();
	void printWordFrequency();

	

private:
	map<string, int> m_WordFre;
	vector<PAIR> m_valueVec;
};


