﻿#include "WordFrequency.h"
#include "LetterFrequency.h"
#include <stdlib.h>
#include <io.h>
#include <Windows.h>

using namespace std;
vector<string> txtFilePath;

int main(int argc, char* argv[])
{
	if (string(argv[1]) == "-help")
	{
		cout << "wf.exe -c <filepath>       -----输出指定英文文本26字母出现的频率" << endl;
		cout << "wf.exe -f <filepath>       -----输出指定英文文本单词出现的频率" << endl;
	}
	else if (string(argv[1]) == "-c" && argc == 3)
	{
		string filePath = argv[2];
		LetterFrequency lf(filePath);  //输出26个英文字母出现频率
		       
	}
	else if (string(argv[1]) == "-f" && argc == 3)
	{
		
		string filePath = argv[2];
		txtFilePath.push_back(filePath);
		WordFrequency wf(txtFilePath);  //输出各个单词的出现频率
		      
	}
	return 0;
}