#include "WordFrequency.h"

WordFrequency::WordFrequency(vector<string> filePath) {
	countWordFrequency(filePath);
	sortWordFrequency();
	printWordFrequency();
}

void WordFrequency::countWordFrequency(vector<string> filePath)
{	
	for (int fileIndex = 0; fileIndex < filePath.size(); fileIndex++)
	{
		//���ļ�
		string strFile, temp;
		ifstream file(filePath.at(fileIndex));
		if (!file.is_open())
		{
			cout << "the file open failed" << endl;
			return;
		}

		//���ж�ȡ�ı�,�����ַ���strFile
		while (getline(file, temp))
		{
			strFile.append(temp);
			temp.clear();
		}
		//������תΪ�ո��
		for (int i = 0; i < strFile.size(); i++)
		{
			if (ispunct(strFile[i]))
				strFile[i] = ' ';
		}
		//��ʶ�ȡ
		stringstream ss(strFile);
		string word;
		while (ss >> word)
		{
			//ͳһת��ΪСд
			for (int i = 0; i < word.size(); i++)
				word[i] = tolower(word[i]);

			if (word[0] >= '0' && word[0] <= '9')
			{
				//��������
				continue;
			}
			
		    //ͳ�Ƶ��ʳ���Ƶ��
			map<string, int >::iterator it = m_WordFre.find(word);
			if (it != m_WordFre.end())
			{
				m_WordFre[word] ++;
			}
			else
			{
				m_WordFre[word] = 1;
			}
			
		}
	}
}

void WordFrequency::sortWordFrequency()
{
	m_valueVec.assign(m_WordFre.begin(), m_WordFre.end());
	sort(m_valueVec.begin(), m_valueVec.end(), cmpWordFrequency());
}

void WordFrequency::printWordFrequency()
{
	for (vector<PAIR>::iterator it = m_valueVec.begin(); it != m_valueVec.end(); it++)
	{
		cout << (*it).first << ": " << (*it).second << endl;
	}
}





