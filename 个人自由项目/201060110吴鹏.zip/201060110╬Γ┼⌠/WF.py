import re
import argparse


def LoadFile(fileName):
    fileDir = 'C:\\Users\\Administrator\\Desktop\\'
    path = fileDir + fileName + '.txt'
    try:
        with open(path,'r',encoding = 'utf-8') as f:
            txt = f.read()
            lowerTxt = txt.lower()
            #print(lowerTxt)
            return lowerTxt        
    except FileNotFoundError:
        print('无法打开指定的文件!')
    except LookupError:
        print('指定了未知的编码!')
    except UnicodeDecodeError:
        print('读取文件时解码错误!')     



def CountAlpha(lowerTxt):
    keyList = [chr(i) for i in range(97,123)]
    wDict = dict.fromkeys(keyList,0)
    num = 0

    for everyChr in lowerTxt:
        for key in wDict:
            if everyChr == key:
                wDict[key] += 1
                num += 1

    for key in wDict:
        wDict[key] = wDict[key] / num

    wDictOrder = sorted(wDict.items(),key = lambda x : x[1],reverse = True)
    wDictOrder = dict(wDictOrder)
    for key,value in wDictOrder.items():
        percent = value * 100
        print('%s : %.2f%%' % (key,percent))

def CountWords(lowerTxt):
    words = re.findall(r'\b[a-z]\w*\b',lowerTxt)
    wordsDict = {}
    for i in words:
        if i not in wordsDict.keys():
            wordsDict[i] = 1
        else:
            wordsDict[i] += 1
    wordsDictOrder = sorted(wordsDict.items(),key = lambda x : x[1],reverse = True)
    wordsDictOrder = dict(wordsDictOrder)
    return wordsDictOrder

def OutPut(wordsDictOrder):
    for key,value in wordsDictOrder.items():
        print('%s : %d' % (key,value))

def OutPutN(wordsDictOrder,n):
    num = 0
    for key,value in wordsDictOrder.items():
        print('%s : %d' % (key,value))
        num += 1
        if num == n:
            break

def SkipWords(wordsDictOrder,fileName):
    num = 0
    fileDir = 'C:\\Users\\Administrator\\Desktop\\'
    path = fileDir + fileName + '.txt'
    try:
        with open(path,'r',encoding = 'utf-8') as f:
            txt = f.read()
            stopWords = re.findall(r'\b[a-z]\w*\b',txt)      
    except FileNotFoundError:
        print('无法打开指定的文件!')
    except LookupError:
        print('指定了未知的编码!')
    except UnicodeDecodeError:
        print('读取文件时解码错误!')  

    for key,value in wordsDictOrder.items():
        if key not in stopWords:
            print('%s : %d' % (key,value))
            num += 1
        else:
            continue
        
        if num == 10:
            break
    


def main():

    ''' parser = argparse.ArgumentParser()    
    parser.add_argument('-c','--count',action = 'store_true',help = '统计26个字母的频率')
    parser.add_argument('file',type = str,help = '统计单词出现的频率')
    
    parser.add_argument('-f','--wordsf',action = 'store_true',help = '统计单词出现的频率')
    parser.add_argument('-n','--wordsn',action = 'store_true',help = '统计出现次数最多的前n个单词')
    parser.add_argument('-x','--skipwords',action = 'store_true',help = '跳过单词表中的单词再计数')
    args = parser.parse_args()

    if args.count:

        fileName = args.file
        txt = LoadFile(fileName)
        CountAlpha(txt)
    elif args.wordsf:
        fileName = args.file
        txt = LoadFile(fileName)
        OutPut(CountWords(txt))
    elif args.wordsf and args.skipwords:
        fileName = args.file
        txt = LoadFile(fileName)
        SkipWords(CountWords(txt),args.x) 
    elif args.wordsn:
        parser.add_argument('num',type = int,help = '统计单词出现的频率')
        args = parser.parse_args()
        fileName = args.file
        txt = LoadFile(fileName)
        OutPutN(CountWords(txt),args.num)  '''
txt1 = str(input('请输入文件名：'))
txt = LoadFile(txt1)
num = int(input('请选择：'))
if num == 1:
    CountAlpha(txt)
elif num == 2:
    OutPut(CountWords(txt))
elif num == 3:
    OutPutN(CoutnWords(txt))
elif num == 4:
    txt2 = str(input('请输入跳过单词表文件名：'))
    SkipWords(CountWords(txt),txt2)



if __name__ == '__main__':
    main()