from selenium import webdriver
import json
import os
import requests

def printPath(path):
    """
    在终端上打印路径
    :param path: 路线列表
    :return:
    """
    print("\n----最短路线----\n")
    for mesg in path:
        print('    '+mesg)

# def updatePath(name):
#     os.system('git add ./js/path/{}'.format(name))
#     os.system("git commit -m '更新path文件'")
#     re = os.system('git push origin master')
#     updated = False
#     while (not updated):
#         if not re:   # fixme 更新成功
#             updated = True

def showMap():
    """
    在地图上显示规划的路径
    :return:
    """
    driver = webdriver.Chrome(executable_path="F:/pycharm/chromedriver.exe")
    # driver = webdriver.Edge(executable_path="F:/pycharm/msedgedriver.exe")
    driver.implicitly_wait(5)

    # TODO 1 把路径信息保存在本地  2 把路径信息更新到git上  3 js解析从而在地图上绘制路径
    # FIXME 网址来源于Gitee Page 受限于前后端知识放弃
    # driver.get('http://xyf97.gitee.io/subway-route-planning')
    driver.get('file:///'+os.path.abspath('index.html'))
    input('wait..')

def showPath(path, terminal=True, map=False):
    """
    显示规划的路径
    :param path:
    :param terminal: 是否在终端显示
    :param map: 是否在地图上显示
    :return:
    """
    pathLog = []  # 变换一下形式，方便操作

    curline = path[1]  # 起始线路
    for i in range(len(path)):
        if i == 0:
            pathLog.append(path[i] + ' ⬇ {}'.format(path[1]))
        elif i % 2 == 0 and (i + 2) == len(path):
            # 到站
            pathLog.append(path[i] + ' *到站*')
        elif i % 2 == 0 and curline != path[i + 1]:
            # 换线了
            curline = path[i + 1]
            pathLog.append(path[i] + ' *换乘* ⬇ {}'.format(curline))
        elif i % 2 == 0:
            # 其它只打印车站名
            pathLog.append(path[i])

    if terminal:
        printPath(pathLog)

    if map:
        path = {}
        for n, i in  enumerate(pathLog):
            temp = i.split()
            if n==0:
                path[temp[0]] = 's'  # 第一个肯定是起点
                start = temp[0]
            elif len(temp)>1 and temp[1] == '*到站*':
                path[temp[0]] = 'end'
                end = temp[0]
            # 换乘
            elif len(temp)>1 and temp[1] == '*换乘*':
                path[temp[0]] = 'ch'
            else:
                path[temp[0]] = '0'
        # print(path)
        with open('path.js', 'w', encoding='utf-8') as jsfile:
            js_content = 'var data = ' + str(path)
            jsfile.write(js_content)

        showMap()

if __name__ == '__main__':
    showMap()