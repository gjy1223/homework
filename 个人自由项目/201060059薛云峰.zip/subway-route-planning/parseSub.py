import json
import requests
from os.path import isfile

BeiJing = 'http://map.amap.com/service/subway?_1615466846985&srhdata=1100_drw_beijing.json'

def getLatestSubways(url=BeiJing):
    """
        根据URL爬取指定城市地铁信息json，并保存
        :param url: 目标城市高德地铁图json网址
        :return:
    """
    response = requests.get(url)
    result = json.loads(response.text)
    with open("./js/BJ.json", 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False)
        print('\n\n********* 地铁信息更新成功！**********\n\n')

def parseSubwaysJson(update=False):
    """
    解析城市地铁信息
    :param update:
    :return: subways: {'line':
                                {
                                    'station': {'id':id, ... },
                                    ...
                                },
                        ...
                      }
    """
    if update or (not isfile('./js/BJ.json')):
        getLatestSubways()

    with open("./js/BJ.json", 'r', encoding='utf-8') as json_file:
        result = json.load(json_file)

    subways = {}
    looplines = []
    for line in result['l']:
        # 对于每条地铁线
        stations = {}
        lname = line['ln']

        # 判断是否是环行线
        if line['c'][0] == line['c'][-1]:
            # print(lname+'是环行线\n')
            looplines.append(lname)

        # 解析有用信息
        for st in line['st']:
            # 里面的每个地铁站
            sname = st['n']
            sinfo = {} # 保存站点的信息
            sinfo['sid'] = st['sid']
            stations[sname] = sinfo
        subways[lname] = stations

    return subways, looplines

if __name__ == '__main__':
    lines = parseSubwaysJson()
    print(lines)