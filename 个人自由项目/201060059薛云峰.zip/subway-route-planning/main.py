from parseSub import parseSubwaysJson
from showpath import showPath

def buildSubwaysGraph():
    """
    构建图，每一个站点的邻接表
    :return:
    """
    # 从json文件读取地铁信息
    lines, looplines = parseSubwaysJson(update=False)
    # print(lines)
    stations = []
    for l in lines.items():  # 对于每一个line
        for st in l[1].keys():
            stations.append(st)
    stations = set(stations)  # 站点sname所组成的集合，无序不重复元素集
    graph = {}
    for station in stations:  # 对于每一个站点，生成对应的邻接表
        next_station = {}               # 字典，该站点可以去的站点
        for lname in lines.keys():      # 对于每条线line
            line = list(lines[lname].keys())
            if station in line:      # 如果该站点在线上
                idx = line.index(station)      # 该站点在线上的位置
                if idx == 0:  # 如果是首位
                    next_station[line[1]] = lname  # next_station = {'第二站名': 'lines[key]'}
                elif idx == len(line) - 1:  # 如果是末尾
                    next_station[line[idx - 1]] = lname  # next_station = {'倒数第二站名': 'lines[key]'}
                else:
                    next_station[line[idx - 1]] = lname  # 其它情况
                    next_station[line[idx + 1]] = lname  # next_station = {'上一站名': 'lines[key]', '下一站名': 'lines[key]'}
        graph[station] = next_station  # 保存站点对应的邻接表

    '''针对环行线特殊处理'''
    for ll in looplines:
        if ll == u'首都机场线':
            # 首都机场线是个形状诡异的环状特殊对待
            graph[u'T3航站楼'][u'三元桥'] = u'首都机场线'
            graph[u'三元桥'][u'T3航站楼'] = u'首都机场线'
        else:
            # usually
            first_st = list(lines[ll].keys())[0]
            last_st = list(lines[ll].keys())[-1]
            graph[first_st][last_st] = ll
            graph[last_st][first_st] = ll
    return graph  # 字典，每一项对应一个邻接表

def path_search(start, goal, graphs):
    """
    找到从起始点到目标站的最小距离路线

    末节点之后，再加入一个元组：(linenum, changetimes)
    linenum    ：表示上一次的地铁线路，
    changetimes：表示当前情况下的换乘次数。这时我们要引入优先队列的概念，用最小堆来实现的话比较复杂，不如直接对列表进行排序。这样，对上述算法略微修改，就可以得到新的函数：
    """
    if start == goal:
        return [start]

    # transfers = []
    # for st in graphs:
    #     '''
    #     对于每个站点，检查其邻接表内的点是否含有来自两个线路的站点，如果有表明这是一个换乘站
    #     '''
    #     goals = []
    #     for g in st:
    #         goals.append(g)
    #     if len( set(goals) ) > 1:  # 目标线路的集合中包含1中以上站点，说明该站点是可以换乘的
    #         transfers.append(st)

    explored = set()  # 保存已经探索过的站点
    queue = [ [start, ('', 0)] ]
    while queue:
        path = queue.pop(0)
        s = path[-2]
        linenum, changetimes = path[-1]

        if s == goal:
            return path

        for state, action in graphs[s].items():
            if state not in explored:
                linechange = changetimes
                explored.add(state)
                if linenum != action and not (state in graphs[start]):  # 如果下一站是，首站是换乘站的目标点，无需+1
                    print(state)
                    linechange += 1
                path2 = path[:-1] + [action, state, (action, linechange)]
                queue.append(path2)
                queue.sort(key=lambda path:path[-1][-1])
    return []

def testStationName(st, graph):
    """
    检测输入的地铁站名称是否正确
    :param st:
    :param graph:
    :return:
    """
    if not(st in graph.keys()):
        print("站点 {} 不存在，请核实\n".format(st))
        return False
    return True

def printInfo():
    print("请输入正确的出发和目标站点名称，例如：田村 <enter>\n玉泉路 <enter>\n ")
# Press the green button in the gutter to run the script.

def subwayRoutePlaning():
    """
    主程序，输入起始站点和目的，快速规划最短路径
    :return:
    """

    print("***** 快速规划地铁出行 ****")
    '''
        生成图
    '''
    subway_graph = buildSubwaysGraph()
    # print(subway_graph)
    '''
        输入目的地
    '''
    isInput = True
    while isInput:
        printInfo()
        start = input(" > 请输入始发站：").strip()    # 去除空格
        if not testStationName(start, subway_graph):
            continue
        goal = input(" > 请输入目的站：").strip()
        if not testStationName(goal, subway_graph):
            continue
        break
    '''
        寻找最近线路
    '''
    path = path_search(start, goal, subway_graph)
    # 展示路线
    showPath(path, terminal=True, map=True)

if __name__ == '__main__':
    subwayRoutePlaning()

