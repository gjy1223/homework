import re
import argparse
stop_list = ['a','an','the','this','that','to','is','was','as','he','she','they','in','on','and','of','had','her','you','it','his',
             'with','for','at','but','have']

class CountCharacterFrequence():

    def __init__(self,path):
        self.char_dict = dict()
        
        with open(path,encoding='utf-8') as fp:
            data = fp.read()
            list_obj_a = re.findall("[a-z]",data)         #匹配所有小写字母
            list_obj_A = re.findall("[A-Z]",data)         #匹配所有大写字母
        for j in list_obj_a:
            self.char_dict[j] = self.char_dict.get(j,0) + 1      #利用字典对列表单词计数
        for j in list_obj_A:
            self.char_dict[j] = self.char_dict.get(j,0) + 1      #利用字典对列表单词计数             
    
    def count(self):
           
        char_seq = sorted(self.char_dict.items(),key=lambda x:x[1],reverse=True)
        sum_num = 0
        for i in range(len(char_seq)):
            sum_num +=char_seq[i][1]
        for j in range(len(char_seq)):
            char_seq[j] = list(char_seq[j])
            char_seq[j][1] /=sum_num
            char_seq[j][1] = '{:.4%}'.format(char_seq[j][1])
        return char_seq   



class CountWordsFrequence():

    def __init__(self,path):
        self.word_dict = dict()
        
        with open(path,encoding='utf-8') as fp:
            data = fp.read()
            data_lower = data.lower()                      #将所有字母转为小写
            list_obj = re.findall("\s[a-z]\w+",data_lower) #要求每段以空格开头
            for i in range(len(list_obj)):                 #对匹配完成的列表进行处理，去除空格和换行符
                list_obj[i] = list_obj[i][1:]
            for j in list_obj:
                self.word_dict[j] = self.word_dict.get(j,0) + 1      #利用字典对列表单词计数  
    
    def count(self):    
        word_seq = sorted(self.word_dict.items(),key=lambda x:x[1],reverse=True)
        return word_seq  
    



parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group()
group.add_argument('-c','--countChars',help='Count Characters',action='store_true')
group.add_argument('-f','--countWords', help="Count Words",action = 'store_true')
group.add_argument('-n','--countTopWords',help="Count Top Words",action = 'store_true')
group.add_argument('-STOP','--countTopWords_STOP',help="Count Words support STOP",action = 'store_true')
parser.add_argument('path', help="Operate file/dic")

if __name__ == "__main__":
    args = parser.parse_args()
    if args.countChars:
        top_characters = CountCharacterFrequence(args.path).count()  #输出所有字母降序排列
        print ("最常出现字母:" )
        for i in top_characters:
            print(i)
    elif args.countWords:        
        top_words = CountWordsFrequence(args.path).count()          #输出所有单词降序排列
        print ("最常出现单词:" )
        for i in top_words:
            print(i)
    elif args.countTopWords:
        top_words = CountWordsFrequence(args.path).count()         #输出前n个单词降序排列
        num = int((input("需要前几个最常出现单词：")))
        print ("最常出现单词:" )
        for i in range(num):
            print(top_words[i])
    elif args.countTopWords_STOP:
        top_words = CountWordsFrequence(args.path).count()           #STOP模式输出
        print ("最常出现单词:" )
        for i in top_words:
            if i[0] not in stop_list:
                print(i)     
    else:
        print("错误：请输入正确的操作命令！")











